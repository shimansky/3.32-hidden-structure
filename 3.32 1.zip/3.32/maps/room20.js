   var map =[
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",],
["w","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","w","o","o","o","o","o","o","o","o","o","o","o","o","w","gr","o","o","w",],
["w","ground","ground","ground","ground","ground","ground","ground","ground","ground","ground","gr","w","o","o","o","o","o","o","o","o","o","o","o","o","w","gr","o","o","w",],
["w","as","as","as","as","as","as","as","as","as","ground","gr","w","w","w","w","w","ud","w","w","w","o","o","o","o","w","gr","o","o","w",],
["w","ash","ash","ash","ash","ash","ash","ash","as","as","ground","gr","gr","gr","gr","gr","gr","ground","gr","gr","w","o","o","o","o","w","gr","o","o","w",],
["w","as","as","as","as","as","as","as","asv","as","ground","ground","ground","ground","ground","ground","ground","ground","ground","gr","w","w","w","w","w","w","gr","o","o","w",],
["w","ground","ground","ground","ground","ground","ground","as","asv","as","as","as","as","as","as","as","as","as","ground","gr","gr","gr","gr","gr","gr","gr","gr","ground","o","w",],
["w","gr","gr","gr","gr","gr","ground","as","as","ash","ash","ash","ash","ash","ash","ash","as","as","ground","gr","gr","gr","gr","gr","gr","gr","ground","ground","o","w",],
["w","gr","gr","gr","gr","gr","ground","as","as","as","as","as","as","asv","as","as","as","as","ground","ground","gr","gr","gr","gr","gr","gr","ground","ground","o","w",],
["w","gr","gr","gr","gr","gr","ground","ground","ground","ground","ground","ground","as","asv","as","ground","ground","ground","ground","ground","gr","gr","gr","ground","ground","ground","ground","ground","o","w",],
["w","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","ground","as","asv","as","ground","ground","ground","ground","ground","ground","ground","ground","ground","ground","ground","ground","ground","o","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","as","as","as","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",],
["w","as","asv","as","asv","as","asv","as","asv","as","asv","w","as","as","as","w","asv","as","asv","as","asv","as","asv","as","asv","as","asv","as","as","w",],
["w","as","asv","as","asv","as","asv","as","asv","as","asv","as","as","as","as","as","asv","as","asv","as","asv","as","asv","as","asv","as","asv","as","as","w",],
["w","ash","as","ash","as","ash","as","ash","as","ash","as","as","as","as","as","as","as","ash","as","ash","as","ash","as","ash","as","ash","as","as","as","w",],
["w","as","as","w","w","w","w","w","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","w",],
["w","as","as","w","o","o","o","w","as","as","as","as","as","as","as","as","as","asv","as","w","w","ud","w","w","ud","w","w","w","as","w",],
["w","as","as","w","o","o","o","w","as","as","asv","as","as","as","as","as","as","asv","as","w","o","o","o","w","o","w","o","w","as","w",],
["w","as","as","w","o","o","o","w","as","as","asv","as","as","as","as","as","as","w","w","w","w","w","ud","w","o","w","o","w","as","w",],
["w","as","as","w","ud","w","w","w","w","w","w","as","as","as","as","ash","ash","w","o","o","w","o","o","w","o","w","o","w","as","w",],
["w","as","as","w","o","w","o","o","o","o","w","as","as","as","asv","as","as","w","wp","o","ud","o","wp","w","o","o","o","w","as","w",],
["w","as","as","w","o","w","o","o","o","o","w","as","as","as","as","ash","ash","w","o","o","w","o","o","w","ud","w","w","w","as","w",],
["w","as","as","w","o","w","o","o","o","o","w","as","as","as","asv","as","as","w","wp","o","w","o","wp","w","o","o","o","w","as","w",],
["w","as","as","w","o","w","ud","w","w","o","w","as","as","as","as","ash","ash","w","o","o","w","o","o","w","o","o","wp","w","as","w",],
["w","as","as","w","o","o","o","w","o","o","w","as","as","as","asv","as","as","w","wp","o","ud","o","wp","w","o","o","o","w","as","w",],
["w","as","as","w","o","o","o","w","o","o","w","as","as","as","as","ash","ash","w","o","o","w","o","o","w","o","wp","o","w","as","w",],
["w","as","as","w","w","w","w","w","w","ud","w","as","as","as","as","as","as","w","w","w","w","w","w","w","w","w","w","w","as","w",],
["w","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","w",],
["w","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",]

         ];
   
   var teleportX = 400;
   var teleportY = -50;
   var moduls = 5;

   var isVisited = localStorage.getItem('level'+ tempLocation);
   console.log("level is visited: " + isVisited);

   if(isVisited==1){
    monster.style.display="none";
    monster2.style.display="none";
    monsterPortal.style.display="none";
    controlPanel.style.backgroundImage='URL("IMG/controlPanelOFF.jpg")';
   
        try{
            off();
            turelActive=0;
            bullet.style.display="none";
            toggle=0;
            
            }
        catch{

            }
            
   }
   else{
      // alert("Find all the alarm-modules, otherwise you will die from nerve gas. you have 150 seconds!");
   }