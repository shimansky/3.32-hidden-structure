   var map =[

      ["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","we","we","we","we","we","we","we","we","we","we","we",],
["w","oa","oa","oa","w","ow","o","o","o","o","o","o","o","ow","w","o","o","o","w","we","we","we","we","we","we","we","we","we","we","we",],
["w","oa","oa","oa","w","ow","o","o","o","o","o","o","o","ow","w","o","o","o","w","we","we","we","we","we","we","we","we","we","we","we",],
["w","oa","oa","oa","ud","ow","o","o","o","o","o","o","o","ow","ud","o","o","o","w","we","we","we","we","we","we","we","we","we","we","we",],
["w","w","w","ud","w","w","o","o","o","o","o","o","o","w","w","ud","w","w","w","we","we","we","we","we","we","we","we","we","we","we",],
["w","ow","ow","ow","w","b","o","o","o","o","o","o","o","b","w","ow","ow","ow","w","we","we","we","we","we","we","we","we","we","we","we",],
["w","o","o","o","o","o","o","o","o","o","o","o","o","o","o","o","o","o","w","we","we","we","we","we","we","we","we","we","we","we",],
["w","o","o","o","o","o","o","o","o","o","o","o","o","o","o","o","o","o","w","we","we","we","we","we","we","we","we","we","we","we",],
["w","o","o","o","o","o","o","o","o","o","o","o","o","o","o","o","o","o","w","we","we","we","we","we","we","we","we","we","we","we",],
["w","ow","ow","ow","w","b","o","o","o","o","o","o","o","b","w","ow","ow","ow","w","we","we","we","we","we","we","we","we","we","we","we",],
["w","w","w","ud","w","w","o","o","o","o","o","o","o","w","w","ud","w","w","w","we","we","we","we","we","we","we","we","we","we","we",],
["w","flf","flf","flf","ud","ow","o","o","o","o","o","o","o","ow","ud","flu","flu","flu","w","we","we","we","we","we","we","we","we","we","we","we",],
["w","flf","flf","flf","w","ow","o","o","o","o","o","o","o","ow","w","flu","flu","flu","w","we","we","we","we","we","we","we","we","we","we","we",],
["w","flf","flf","flf","w","ow","o","o","o","o","o","o","o","ow","w","flu","flu","flu","w","we","we","we","we","we","we","we","we","we","we","we",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","we","we","we","we","we","we","we","we","we","we","we",],
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",]

                ];
   
   var teleportX = 400;
   var teleportY = -50;
   var moduls = 5;
   var alienMaximum = 1;
   var alienCounter = 0;
   var alienKilledCounter = alienMaximum+2;
   var newAliensWave = new Audio('SOUND/newAliensWave.mp3');
   var stateCounter = 1;
   var aliveAlienCounter = 0;


   let al = new Enemy("alien", "alien", 480, 1100);
   al.startSelf();

   function alienWawes() {
      if(aliveAlienCounter<=15){
         newAliensWave.play();
         alienCounter = 0;
         alienKilledCounter = alienMaximum+2
        let mon  = "monster" +(++stateCounter);
          mon = new Enemy("alien", "alien", 480, 1100);
   mon.startSelf();
   console.log("new Alien wawe!!!");
     }else{
      console.log("TO MANY ALIENS!" + aliveAlienCounter);
     } 
   }

   let timeToNewWave = 3000;

   if (localStorage.getItem('difficult') == 5) {
      timeToNewWave = 30000;
   }

   if (localStorage.getItem('difficult') == 10) {
      timeToNewWave = 20000;
   }

   if (localStorage.getItem('difficult') == 15) {
      timeToNewWave = 15000;
   }

   if (localStorage.getItem('difficult') == 20) {
      timeToNewWave = 10000;
   }


   setInterval(alienWawes,timeToNewWave);

