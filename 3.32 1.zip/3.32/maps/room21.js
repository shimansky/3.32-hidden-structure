   var map =[
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",],
["w","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","oa","w","oa","as","as","as","as","as","as","as","as","w",],
["w","as","oa","oa","oa","oa","oa","b","oa","b","oa","oa","oa","oa","oa","b","b","oa","oa","w","oa","as","as","as","as","as","as","as","as","w",],
["w","as","oa","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","b","ash","ash","as","as","as","as","ash","ash","w",],
["w","as","oa","w","bth","w","tol","w","wrd","wrd","bed","w","wrd","bed","o","w","wrd","wrd","wrd","w","oa","as","as","as","as","as","as","as","as","w",],
["w","as","oa","w","flu","snk","flu","w","o","o","o","w","o","o","o","w","flf","flf","flf","w","oa","ash","ash","as","as","as","as","ash","ash","w",],
["w","as","oa","w","w","rdo","w","w","o","o","o","w","o","o","o","w","flf","wrd","wrd","w","b","as","as","as","as","as","as","as","as","w",],
["w","as","b","w","flf","flf","flf","w","w","rdo","w","w","w","ws","w","w","rdo","w","w","w","oa","ash","ash","as","as","as","as","ash","ash","w",],
["w","as","oa","ws","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","w","b","as","as","as","as","as","as","as","as","w",],
["w","as","b","w","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","w","oa","ash","ash","as","as","as","as","ash","ash","w",],
["w","as","oa","w","w","rdo","w","w","w","ws","w","w","w","rdo","w","w","w","rdo","w","w","oa","as","as","as","as","as","as","as","as","w",],
["w","as","oa","w","o","o","o","w","o","o","o","w","wrd","o","o","w","flf","flf","flf","w","b","ash","ash","as","as","as","as","ash","ash","w",],
["w","as","oa","w","o","o","o","w","o","o","o","w","o","o","o","w","flf","flf","flf","w","oa","as","as","as","as","as","as","as","as","w",],
["w","as","oa","w","wrd","bed","o","w","o","bed","wrd","w","o","bed","o","w","flf","flf","flf","w","b","ash","ash","as","as","as","as","ash","ash","w",],
["w","as","oa","w","w","w","w","w","w","w","w","w","w","w","w","w","w","rdo","w","w","oa","as","as","as","as","as","as","as","as","w",],
["w","as","oa","oa","b","b","oa","oa","w","oa","b","oa","b","oa","oa","w","b","oa","b","w","oa","ash","ash","as","as","as","as","ash","ash","w",],
["w","as","as","as","as","as","as","oa","w","oa","gr","gr","gr","gr","gr","w","oa","oa","oa","oa","oa","as","as","as","as","as","as","as","as","w",],
["w","as","as","as","as","as","as","oa","w","oa","gr","bg","bg","gr","gr","w","oa","oa","oa","oa","oa","as","as","as","as","as","as","as","as","w",],
["w","as","as","as","as","as","as","oa","w","oa","gr","bg","gr","gr","gr","w","oa","oa","oa","w","oa","as","as","as","as","asv","as","as","as","w",],
["w","as","oa","b","oa","oa","b","oa","w","oa","gr","gr","gr","gr","gr","w","w","w","w","w","oa","as","as","as","as","asv","as","as","as","w",],
["w","as","oa","w","w","w","w","w","w","b","oa","oa","oa","oa","gr","gr","gr","gr","gr","w","oa","as","as","as","as","as","as","as","as","w",],
["w","as","b","w","flf","flf","flf","flf","w","w","w","w","w","oa","bg","gr","gr","gr","gr","w","oa","as","as","as","as","asv","as","as","as","w",],
["w","as","b","w","flf","flf","flf","flf","w","flf","flf","flf","w","b","gr","gr","gr","gr","gr","w","oa","as","as","as","as","asv","as","as","as","w",],
["w","as","oa","w","flf","flf","flf","flf","rdo","flf","flf","flf","rdo","oa","gr","gr","gr","gr","gr","w","oa","as","as","as","as","asv","as","as","as","w",],
["w","as","oa","rdo","flf","flf","flf","flf","w","flf","flf","flf","w","b","gr","gr","gr","gr","w","w","oa","as","as","as","as","asv","as","as","as","w",],
["w","as","oa","w","flf","flf","flf","flf","w","w","w","w","w","oa","bg","gr","bg","gr","bg","w","oa","as","as","as","as","asv","as","as","as","w",],
["w","as","b","w","w","w","w","w","w","oa","oa","oa","oa","oa","gr","gr","gr","gr","gr","w","oa","as","as","as","as","as","as","as","as","w",],
["w","as","oa","oa","oa","oa","oa","b","w","oa","gr","gr","gr","gr","gr","gr","gr","gr","gr","w","oa","as","as","as","as","asv","as","as","as","w",],
["w","as","as","as","as","as","as","as","w","oa","gr","bg","bg","gr","gr","gr","bg","gr","gr","w","oa","as","as","as","as","asv","as","as","as","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",]
         ];
   
   var teleportX = 400;
   var teleportY = -50;
   var moduls = 5;

   var alienMaximum = 8;
   var alienCounter = 0;

   let al = new Enemy("alien", "alien", 350, 1000);
   al.startSelf();

   var isVisited = localStorage.getItem('level'+ tempLocation);
   console.log("level is visited: " + isVisited);

   if(isVisited==1){
    monster.style.display="none";
    monster2.style.display="none";
    monsterPortal.style.display="none";
    controlPanel.style.backgroundImage='URL("IMG/controlPanelOFF.jpg")';
   
        try{
            off();
            turelActive=0;
            bullet.style.display="none";
            toggle=0;
            
            }
        catch{

            }
            
   }
   else{
      // alert("Find all the alarm-modules, otherwise you will die from nerve gas. you have 150 seconds!");
   }