   var map =[

      ["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",],
["w","b","oa","oa","b","w","oa","w","w","w","oa","w","b","o","o","grass","oa","oa","oa","oa","oa","oa","oa","oa","o","w","w","o","b","w",],
["w","grass","oa","flf","oa","w","ws","w","w","w","ws","w","oa","grass","o","w","oa","o","o","oa","flf","oa","o","o","o","ud","ow","o","o","w",],
["w","gr","w","w","oa","oa","op","o","o","o","op","o","oa","w","o","oa","oa","grass","o","oa","oa","oa","grass","grass","o","w","w","o","o","w",],
["w","gr","w","b","grass","grass","op","grass","grass","grass","op","grass","oa","oa","oa","w","o","w","ws","w","w","ws","w","w","ws","w","oa","oa","o","w",],
["w","oa","oa","grass","gr","w","ws","w","w","w","ws","w","oa","flf","oa","grass","grass","w","oa","w","w","oa","w","w","oa","w","flf","oa","o","w",],
["w","flf","oa","gr","gr","w","oa","w","w","w","oa","w","oa","oa","oa","w","w","w","w","w","w","w","w","w","w","w","oa","oa","oa","w",],
["w","w","oa","gr","w","w","w","w","w","w","w","w","w","w","w","w","b","op","oa","flf","oa","op","oa","o","w","w","o","oa","flf","w",],
["w","b","oa","gr","b","w","w","w","o","o","o","oa","oa","oa","o","o","o","op","oa","oa","oa","op","oa","o","w","w","o","oa","oa","w",],
["w","w","oa","oa","w","w","w","w","o","o","o","oa","flf","oa","o","o","grass","op","grass","grass","grass","op","flf","b","w","w","grass","o","grass","w",],
["w","oa","flf","oa","gr","ws","oa","w","o","oa","oa","oa","oa","oa","o","b","w","w","w","w","w","w","w","chain","w","w","w","ud","w","w",],
["w","oa","oa","oa","gr","w","w","w","o","oa","flf","w","w","w","w","w","w","oa","oa","oa","oa","oa","oa","oa","oa","w","w","ow","w","w",],
["w","b","gr","oa","b","w","w","w","o","oa","flf","w","oa","oa","oa","oa","oa","oa","w","w","w","w","w","w","w","w","o","o","o","w",],
["w","grass","gr","oa","gr","w","w","w","o","oa","oa","w","oa","w","w","w","w","w","w","bth","flu","tol","snk","w","w","w","o","o","o","w",],
["w","gr","gr","oa","grass","ws","oa","w","o","o","o","w","oa","w","flf","flf","flf","w","w","flu","flu","flu","flu","w","oa","ws","o","o","o","w",],
["w","w","gr","oa","w","w","w","w","o","o","o","w","oa","w","flf","flf","wc","w","w","w","ud","w","w","w","w","w","o","o","o","w",],
["w","b","gr","oa","b","w","w","w","o","o","o","w","oa","w","flf","wc","wc","w","flf","flf","flf","flf","flf","w","w","w","o","o","o","w",],
["w","oa","oa","oa","gr","w","w","w","o","o","o","w","oa","w","flf","flf","flf","ud","flf","flf","flf","flf","se","w","oa","ws","oa","oa","o","w",],
["w","flf","oa","gr","gr","ws","oa","w","oa","oa","oa","w","oa","w","flf","wc","wc","w","se","flf","flf","flf","flf","w","w","w","o","oa","oa","w",],
["w","w","oa","gr","w","w","w","w","flf","oa","o","w","oa","w","flf","wc","flf","w","flf","flf","flf","flf","se","w","w","w","o","oa","flf","w",],
["w","b","oa","gr","b","w","w","w","oa","oa","o","w","oa","w","flf","wc","flf","w","se","flf","flf","flf","flf","w","oa","ws","o","oa","oa","w",],
["w","w","oa","oa","w","w","w","w","o","o","o","w","oa","w","flf","flf","flf","w","flf","flf","flf","flf","se","w","w","w","o","oa","flf","w",],
["w","gr","oa","flf","oa","ws","oa","w","oa","o","o","w","oa","w","flf","flf","flf","w","se","flf","flf","flf","flf","w","w","w","o","oa","oa","w",],
["w","gr","oa","oa","oa","w","w","w","oa","oa","oa","w","oa","w","w","w","chain","w","flf","flf","flf","flf","flf","w","oa","ws","o","o","o","w",],
["w","b","gr","oa","b","w","w","w","oa","flf","oa","w","oa","oa","oa","oa","oa","w","w","w","ud","w","w","w","w","w","o","o","o","w",],
["w","w","gr","oa","w","w","w","w","oa","oa","oa","w","w","w","w","w","w","w","w","ow","ow","ow","w","w","w","w","o","o","o","w",],
["w","o","gr","oa","oa","ws","oa","w","o","o","oa","w","o","o","op","o","o","w","bg","gr","grass","grass","o","o","op","o","o","o","o","w",],
["w","grass","gr","gr","grass","w","w","w","o","o","o","ud","o","o","op","o","o","w","gr","gr","gr","gr","grass","grass","op","o","o","o","o","w",],
["w","gr","gr","gr","gr","w","w","w","b","o","o","w","oa","grass","op","grass","grass","w","gr","bg","gr","gr","gr","gr","op","grass","grass","grass","b","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",]

                ];
   
   var teleportX = 400;
   var teleportY = -50;
   var moduls = 5;

