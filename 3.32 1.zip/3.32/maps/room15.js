      var map =[
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],
["we","we","we","we","we","we","w","w","w","w","w","w","w","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],
["we","we","we","we","we","we","w","oa","wc","wc","oa","oa","w","we","we","we","we","we","we","we","we","we","we","we","we","we","w","w","w","we",],
["we","we","we","we","we","we","w","oa","oa","oa","oa","wc","w","we","we","we","we","we","we","we","we","we","we","we","we","we","w","o","w","we",],
["we","we","we","we","we","we","w","oa","wc","oa","oa","oa","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","o","w","we",],
["we","we","we","we","we","we","w","oa","oa","oa","oa","oa","ud","ow","o","o","o","o","o","o","op","o","o","o","o","o","o","o","w","we",],
["we","we","we","we","we","we","w","oa","oa","wc","oa","oa","w","w","w","w","w","w","w","w","ws","w","w","w","w","w","w","o","w","we",],
["we","we","we","we","w","w","w","oa","wc","wc","oa","oa","w","we","we","we","we","we","we","w","oa","w","gr","gr","gr","gr","w","o","w","we",],
["we","we","we","we","w","o","w","oa","oa","oa","oa","wc","w","w","w","w","w","we","we","w","oa","w","gr","gr","gr","gr","w","o","w","we",],
["we","we","we","we","w","o","w","w","w","w","w","w","w","o","w","o","w","we","w","w","oa","w","gr","gr","gr","gr","w","o","w","we",],
["we","we","we","we","w","o","o","o","o","o","o","o","o","o","w","o","w","we","w","oa","oa","w","gr","gr","gr","gr","w","o","w","we",],
["we","we","we","we","w","w","w","w","w","w","w","o","w","w","w","o","w","w","w","wc","oa","w","w","w","gr","gr","w","o","w","we",],
["we","we","we","we","w","gr","gr","gr","gr","gr","op","o","o","o","o","o","o","o","op","oa","oa","oa","oa","w","gr","gr","w","o","w","we",],
["we","we","we","we","w","gr","gr","gr","gr","gr","w","w","w","w","w","w","w","w","w","w","w","w","w","w","gr","w","w","ud","w","w",],
["we","we","we","we","w","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","w","oa","oa","oa","w",],
["we","we","we","we","w","w","w","w","w","w","w","w","gr","w","w","w","w","w","w","w","w","w","w","gr","gr","w","oa","oa","oa","w",],
["we","we","we","we","we","w","oa","oa","oa","oa","oa","w","gr","w","oa","oa","oa","oa","w","oa","oa","se","w","gr","gr","w","oa","oa","oa","w",],
["we","we","we","we","we","w","oa","oa","w","w","w","w","gr","w","oa","oa","oa","oa","ud","oa","oa","oa","w","gr","gr","w","oa","oa","oa","w",],
["we","we","we","we","we","w","oa","oa","w","oa","wp","w","gr","w","oa","oa","oa","oa","w","oa","oa","se","w","gr","gr","w","oa","oa","oa","w",],
["we","we","we","we","we","w","oa","oa","w","oa","oa","w","gr","w","oa","oa","oa","oa","w","w","w","w","w","gr","gr","w","w","ud","w","w",],
["we","we","we","we","we","w","oa","oa","w","ws","w","w","gr","w","oa","oa","oa","oa","w","gr","gr","gr","gr","gr","gr","gr","w","o","w","we",],
["we","we","we","we","we","w","oa","oa","oa","oa","oa","w","gr","w","oa","oa","oa","oa","w","gr","gr","gr","w","w","w","w","w","o","w","we",],
["we","we","we","we","we","w","oa","oa","oa","oa","oa","w","w","w","oa","oa","oa","oa","w","gr","gr","gr","w","o","o","o","o","o","w","we",],
["we","we","we","we","we","w","w","w","oa","w","w","w","gr","w","w","w","oa","w","w","gr","gr","gr","w","o","w","w","w","w","w","w",],
["we","we","we","we","we","we","we","w","oa","w","gr","gr","gr","gr","gr","w","oa","w","gr","gr","gr","gr","w","o","w","o","ud","o","o","w",],
["w","w","w","w","we","we","we","w","oa","w","gr","gr","gr","gr","gr","w","oa","w","gr","gr","gr","gr","w","o","ud","o","w","o","o","w",],
["w","o","o","w","w","w","w","w","ud","w","w","w","w","w","w","w","ud","w","w","w","w","w","w","w","w","w","w","o","o","w",],
["w","o","o","o","o","o","o","o","op","o","o","o","o","o","o","o","op","o","o","o","o","o","o","o","o","o","o","o","o","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",],
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],
         ];
   
   var teleportX = 150;
   var teleportY = 0;
   var moduls = 5;

   var alienMaximum = 4;
   var alienCounter = 0;

   let al = new Enemy("alien", "alien", 750, 1000);
   al.startSelf();


   var isVisited = localStorage.getItem('level'+ tempLocation);
   console.log("level is visited: " + isVisited);

   if(isVisited==1){
    monster.style.display="none";
    monster2.style.display="none";
    monsterPortal.style.display="none";
    controlPanel.style.backgroundImage='URL("IMG/controlPanelOFF.jpg")';
        try{
            off();
            turelActive=0;
            bullet.style.display="none";
            toggle=0;
            
            }
        catch{

            }
            
   }

