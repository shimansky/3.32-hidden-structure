      var map =[
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","snk","tol","w","tol","snk","w","w","w","tol","snk","w","snk","snk","w","tol","snk","w",],
["w","w","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","w","flu","flu","w","flu","flu","chain","chain","chain","flu","flu","w","flu","flu","w","flu","flu","w",],
["w","w","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","w","w","ud","w","ud","w","w","w","w","w","ud","w","w","ud","w","w","ud","w",],
["w","w","flf","flf","w","w","w","w","w","w","flf","flf","flf","flf","flf","flf","flf","flf","w","w","w","b","o","o","o","o","o","o","o","w",],
["w","w","flf","flf","flf","flf","flf","flf","w","w","flf","flf","flf","flf","flf","flf","flf","flf","w","w","w","o","o","o","o","o","o","o","o","w",],
["w","w","flf","flf","flf","flf","flf","flf","w","w","flf","flf","flf","flf","flf","flf","flf","flf","w","w","w","w","w","w","w","w","w","o","o","w",],
["w","w","w","w","w","w","flf","flf","w","w","w","w","w","w","w","w","w","w","w","w","w","o","o","o","o","o","o","o","o","w",],
["w","w","w","w","w","w","flf","flf","b","w","flf","flf","flf","flf","w","b","b","b","w","w","w","o","o","o","o","o","o","o","o","w",],
["w","w","flf","flf","flf","w","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","w","w","w","w","w","b","o","o","b","w","w","w",],
["w","o","flf","flf","flf","ud","flf","flf","b","w","w","w","w","w","w","b","flf","flf","w","w","w","o","o","o","o","o","o","o","o","w",],
["w","w","flf","flf","flf","w","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","w","w","w","o","o","o","o","o","o","o","o","w",],
["w","w","w","w","w","w","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","w","w","w","o","o","o","o","o","o","o","o","w",],
["w","w","flf","flf","flf","w","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","w","w","w","w","w","b","o","o","b","w","w","w",],
["w","o","flf","flf","flf","ud","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","w","w","w","o","o","o","o","o","o","o","o","w",],
["w","w","flf","flf","flf","w","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","w","w","w","o","o","o","o","o","o","o","o","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","ws","ws","w","w","w","w","w","w","w","w","w","w","o","o","w","w","w","w",],
["w","w","w","w","w","w","w","w","w","w","w","o","o","o","o","w","w","w","w","w","w","w","w","w","o","o","w","w","w","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","ws","ws","w","w","w","w","w","w","w","w","w","w","o","o","w","w","w","w",],
["w","w","w","w","w","w","w","w","w","w","w","o","oa","oa","o","w","w","w","w","w","w","w","w","w","o","o","w","w","w","w",],
["w","w","w","w","w","w","w","w","w","w","w","o","oa","oa","o","w","w","as","as","asv","as","as","w","w","o","o","w","w","w","w",],
["w","o","b","o","o","o","o","o","o","b","b","o","oa","oa","o","b","b","as","as","asv","as","as","b","o","o","o","o","b","o","w",],
["w","oa","oa","oa","oa","oa","oa","oa","oa","oa","oa","oa","oa","oa","oa","oa","oa","as","as","asv","as","as","oa","oa","oa","oa","oa","oa","oa","w",],
["w","o","b","b","o","o","o","o","b","b","o","o","oa","oa","o","o","b","ash","ash","ash","ash","ash","b","o","o","o","o","b","b","w",],
["w","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","w",],
["w","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","w",],
["w","as","ash","ash","as","as","ash","ash","ash","as","ash","ash","ash","as","ash","ash","ash","as","ash","ash","ash","as","ash","ash","ash","as","ash","ash","ash","w",],
["w","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","w",],
["w","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",]
         ];
   var asideMenuText = "<div class='taskItem'>tasks:<br>1. find access control panel<br>2.Find the entrance to the secret elevator<br>3. find the code to enter the elevator</div>";

   var teleportX = 400;
   var teleportY = -50;

   var bedroomEntrance = "Кажется через эту решетку можно попасть в соседнее здание, единственный способ - найти инструмент, чтобы ее снять";


   // setTimeout(()=>{
   //   let a1 = new Enemy("alien", "alien", 450, 100);
   // a1.startSelf();

   // let a2 = new Enemy("monsterblob", "monsterblob", 600, 100);
   // a2.startSelf();

   // let a3 = new Enemy("alien", "alien", 900, 100);
   // a3.startSelf();

   // let a4 = new Enemy("alien", "alien", 1040, 700);
   // a4.startSelf();

   // let a5 = new Enemy("monstersnake", "monstersnake", 1000, 700);
   // a5.startSelf();

   // let a6 = new Enemy("alien", "alien", 300, 700);
   // a6.startSelf();
   
   // let a7 = new Enemy("monsterthongle", "monsterthongle", 300, 1050);
   // a7.startSelf();

   // let a8 = new Enemy("monsterthongle", "monsterthongle", 1200, 1100);
   // a8.startSelf();
   // },30100);

   

   


   var isVisited = localStorage.getItem('level'+ tempLocation);
   console.log("level is visited: " + isVisited);

   if(isVisited==1){
    // monster.style.display="none";
    // monster2.style.display="none";
    // monsterPortal.style.display="none";
    controlPanel.style.backgroundImage='URL("IMG/controlPanelOFF.jpg")';
       try{
            off();
            turelActive=0;
            bullet.style.display="none";
            toggle=0;
            
            }
        catch{

            }
            
   }

 document.addEventListener('DOMContentLoaded',  CreateNewArmor(800, 150));