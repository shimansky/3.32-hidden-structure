      var map =[
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",],
["w","o","o","o","w","o","o","o","oa","o","o","o","o","o","o","wc","wc","o","o","o","op","o","o","o","o","o","oa","o","o","w",],
["w","o","o","o","o","o","o","o","o","o","o","o","o","o","o","op","wc","o","o","o","op","o","wc","o","wc","o","o","o","o","w",],
["w","o","o","o","w","o","o","wc","wc","o","o","oa","oa","o","o","op","o","o","o","o","o","o","o","o","o","o","o","o","o","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","o","w","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","ws","w","w",],
["w","o","o","o","oa","oa","op","o","o","o","o","o","wc","o","o","o","o","ow","oa","oa","oa","ow","o","o","o","o","o","o","o","w",],
["w","b","oa","o","o","o","o","o","o","o","op","o","o","o","o","o","o","ow","oa","oa","oa","ow","o","o","o","o","o","o","o","w",],
["w","o","o","op","o","o","o","o","oa","o","o","o","op","wc","o","o","o","ow","b","oa","b","ow","o","o","o","oa","o","o","b","w",],
["w","o","o","op","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","ud","w","w","w","w","w","w","w","w","w","w",],
["w","o","o","o","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","o","w","w","w","w","w","w","w","w","w","w",],
["w","op","o","o","w","wc","o","o","oa","o","o","wc","w","flu","tol","snk","w","w","o","o","o","o","o","o","o","w","o","o","o","w",],
["w","op","o","op","w","o","o","o","o","o","o","o","flu","flu","flu","flu","w","w","o","oa","oa","o","o","wc","o","ud","oa","oa","o","w",],
["w","op","o","o","w","o","o","o","o","o","o","o","w","flu","flu","flu","w","w","o","o","o","o","wc","wc","wc","w","o","o","o","w",],
["w","op","o","o","w","w","w","o","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",],
["w","o","o","op","w","w","w","ud","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",],
["w","o","o","o","o","ow","b","oa","b","ow","o","o","o","o","o","op","o","b","b","o","oa","op","o","o","o","o","o","o","o","w",],
["w","oa","o","o","o","ow","oa","oa","oa","ow","o","o","o","o","op","op","o","o","o","o","oa","op","o","o","o","o","o","wc","o","w",],
["w","o","b","o","o","ow","oa","oa","oa","ow","o","o","o","o","op","o","wc","wc","o","o","o","o","op","oa","o","o","o","o","o","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","o","o","o","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","wc","o","o","w",],
["w","o","o","o","o","o","o","o","wc","o","o","o","o","o","o","o","w","w","oa","o","wc","wc","o","o","w","w","oa","o","o","w",],
["w","o","o","o","o","oa","o","o","o","o","o","oa","o","o","o","oa","w","w","o","o","wc","o","o","o","o","ud","o","o","o","w",],
["w","o","o","wc","o","oa","o","o","o","o","o","o","o","oa","oa","o","w","w","o","o","o","o","o","o","w","w","o","o","o","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","o","w","w","w","w","w","w","w","w","w","w","o","o","o","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","ud","w","w","w","w","w","w","w","w","w","w","o","o","wc","w",],
["w","o","o","o","o","o","oa","o","o","o","o","wc","wc","ow","b","oa","b","ow","o","o","o","o","o","op","o","o","o","o","oa","w",],
["w","o","o","o","o","o","o","wc","o","oa","o","o","o","ow","oa","oa","oa","ow","wc","o","o","o","wc","wc","o","o","o","o","oa","w",],
["w","o","o","wc","b","o","o","o","o","o","o","o","o","ow","oa","oa","oa","ow","wc","o","o","o","op","o","o","o","o","b","o","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",]
         ];
   var asideMenuText = "<div class='taskItem'>run!</div>";

   var teleportX = 400;
   var teleportY = -50;

   var alienMaximum = 2;
   var alienCounter = 0;

   let a1 = new Enemy("alien", "alien", 450, 100);
   a1.startSelf();

   let a2 = new Enemy("monsterblob", "monsterblob", 600, 100);
   a2.startSelf();

   let a3 = new Enemy("alien", "alien", 900, 100);
   a3.startSelf();

   let a4 = new Enemy("alien", "alien", 1040, 600);
   a4.startSelf();

   let a5 = new Enemy("monstersnake", "monstersnake", 800, 600);
   a5.startSelf();

   let a6 = new Enemy("alien", "alien", 300, 600);
   a6.startSelf();
   
   let a7 = new Enemy("monsterthongle", "monsterthongle", 300, 1050);
   a7.startSelf();

   let a8 = new Enemy("monsterthongle", "monsterthongle", 1200, 1100);
   a8.startSelf();
 // document.addEventListener('DOMContentLoaded',  CreateNewArmor(600, 1000));