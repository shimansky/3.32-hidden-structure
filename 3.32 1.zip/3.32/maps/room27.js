      var map =[
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","we","we","we",],
["w","o","o","o","o","w","o","o","ud","ow","oa","o","o","o","oa","w","w","b","o","o","o","o","o","wc","oa","o","w","we","we","we",],
["w","o","o","o","o","ud","ow","o","w","o","o","o","o","o","o","o","o","o","o","o","b","o","o","o","o","o","w","we","we","we",],
["w","o","o","w","w","w","w","w","w","w","w","o","o","w","w","w","w","w","w","w","o","o","oa","o","o","o","w","we","we","we",],
["w","o","o","w","w","w","we","we","we","we","w","o","o","w","w","we","we","we","we","w","w","w","w","w","w","ud","w","we","we","we",],
["w","o","o","oa","b","w","we","we","we","we","w","o","o","o","w","we","we","we","we","we","we","we","we","w","ow","ow","w","we","we","we",],
["w","o","o","wc","wc","w","we","we","we","w","w","b","o","o","w","w","we","we","we","we","we","we","we","w","oa","o","w","we","we","we",],
["w","oa","o","o","o","w","we","we","we","w","o","o","oa","o","o","w","we","we","we","we","we","we","we","w","o","o","w","we","we","we",],
["w","o","oa","o","o","w","we","we","we","w","o","wc","o","o","o","w","we","we","we","we","we","we","we","w","o","o","w","we","we","we",],
["w","w","w","w","w","w","we","we","we","w","w","wc","o","o","w","w","we","we","we","we","we","we","we","w","o","o","w","we","we","we",],
["we","we","we","we","we","we","we","we","we","we","w","w","o","o","w","we","we","we","we","we","we","we","we","w","o","o","w","we","we","we",],
["we","we","we","we","we","we","we","we","we","we","we","w","o","oa","w","we","we","we","we","we","we","we","we","w","o","oa","w","w","w","we",],
["we","we","we","we","we","we","we","we","we","we","we","w","o","o","w","we","we","we","we","we","we","we","we","w","o","o","o","o","w","we",],
["we","we","we","we","we","we","we","we","we","we","we","w","o","o","w","we","we","we","we","we","we","we","we","w","b","o","wc","o","w","we",],
["we","we","we","we","we","we","we","we","we","we","we","w","ow","ow","w","we","we","we","we","we","we","we","we","w","oa","o","wc","wc","w","we",],
["we","we","we","we","we","we","we","we","we","w","w","w","w","ud","w","w","w","we","we","we","we","we","we","w","o","o","w","w","w","we",],
["we","we","we","we","we","we","we","we","we","w","o","o","o","o","o","b","w","we","we","we","we","we","we","w","o","o","w","we","we","we",],
["w","w","w","w","w","w","w","w","w","w","o","o","o","o","o","o","w","we","we","we","we","we","we","w","o","o","w","we","we","we",],
["w","b","o","oa","w","o","o","o","o","w","o","oa","o","o","o","ow","w","w","w","we","we","we","w","w","o","o","w","we","we","we",],
["w","o","o","o","w","o","o","o","ow","ud","o","o","o","o","o","ow","ws","o","w","we","we","we","w","o","o","o","w","we","we","we",],
["w","o","o","o","ud","ow","o","o","o","w","o","o","o","o","o","ow","w","w","w","we","we","we","w","wc","o","o","w","we","we","we",],
["w","ud","w","w","w","w","w","w","w","w","o","o","oa","o","o","oa","w","we","we","we","we","we","w","wc","o","o","w","we","we","we",],
["w","ow","o","o","w","we","we","we","we","w","b","o","o","o","o","o","w","we","we","we","we","we","w","w","o","o","w","we","we","we",],
["w","o","o","o","w","we","we","we","we","w","w","w","ud","w","w","w","w","we","we","we","we","we","we","w","o","o","w","we","we","we",],
["w","o","ow","o","w","we","we","we","we","we","we","w","ow","ow","w","we","we","we","we","we","we","we","we","w","o","b","w","we","we","we",],
["w","w","ud","w","w","we","we","we","we","we","we","w","o","o","w","w","w","w","w","w","w","w","w","w","o","oa","w","we","we","we",],
["w","o","o","oa","w","we","we","we","we","we","we","w","o","o","o","oa","oa","o","o","o","o","o","o","o","o","o","w","we","we","we",],
["w","o","o","o","w","we","we","we","we","we","we","w","b","o","o","o","o","o","o","o","o","o","o","o","o","o","w","we","we","we",],
["w","o","o","o","w","we","we","we","we","we","we","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","we","we","we",],
["w","w","w","w","w","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",]
         ];
   var asideMenuText = "<div class='taskItem'>run!</div>";

   var teleportX = 400;
   var teleportY = -50;

   var alienMaximum = 2;
   var alienCounter = 0;

   let a1 = new Enemy("alien", "alien", 450, 100);
   a1.startSelf();

   let a2 = new Enemy("monsterblob", "monsterblob", 600, 100);
   a2.startSelf();

   let a3 = new Enemy("alien", "alien", 900, 100);
   a3.startSelf();

   let a4 = new Enemy("alien", "alien", 1040, 600);
   a4.startSelf();

   let a5 = new Enemy("monstersnake", "monstersnake", 800, 600);
   a5.startSelf();

   let a6 = new Enemy("alien", "alien", 300, 600);
   a6.startSelf();
   
   let a7 = new Enemy("monsterthongle", "monsterthongle", 300, 1050);
   a7.startSelf();

   let a8 = new Enemy("monsterthongle", "monsterthongle", 1200, 1100);
   a8.startSelf();
 // document.addEventListener('DOMContentLoaded',  CreateNewArmor(600, 1000));