   var map =[
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",],
["w","o","wp","w","o","wp","w","o","o","ud","ow","op","o","o","o","o","o","o","o","o","op","ow","ud","o","o","o","o","o","o","w",],
["w","o","w","w","o","w","w","o","o","w","w","w","w","w","w","w","w","w","w","w","w","w","w","o","wc","o","wc","wc","o","w",],
["w","o","o","o","o","o","o","o","o","ud","o","o","o","o","o","o","w","we","we","w","se","oa","w","o","o","o","o","wc","o","w",],
["w","o","o","o","o","o","o","o","o","w","w","w","w","w","w","o","w","we","we","w","w","oa","w","o","wc","wc","o","o","o","w",],
["w","w","w","ud","w","w","w","ud","w","w","oa","oa","oa","se","w","o","w","we","we","w","se","oa","ud","o","wc","o","o","wc","o","w",],
["we","w","oa","oa","oa","w","oa","oa","oa","w","oa","oa","oa","w","w","o","w","we","we","w","w","w","w","w","w","w","w","w","o","w",],
["we","w","oa","oa","oa","w","oa","oa","oa","ud","oa","oa","oa","se","w","o","w","we","we","we","we","we","we","we","we","we","we","w","o","w",],
["we","w","w","oa","w","w","w","w","w","w","oa","oa","oa","oa","w","o","w","we","we","we","we","we","we","we","we","we","we","w","o","w",],
["we","we","w","oa","w","we","we","we","we","w","w","w","w","w","w","o","w","w","w","w","w","w","w","w","w","w","w","w","ws","w",],
["we","we","w","oa","w","w","w","we","we","we","we","we","we","we","w","o","ws","oa","oa","oa","oa","oa","oa","oa","oa","oa","oa","oa","oa","w",],
["we","we","w","oa","oa","oa","w","w","w","w","w","w","w","w","w","o","w","w","w","w","w","oa","oa","oa","oa","oa","oa","oa","oa","w",],
["we","we","w","oa","oa","oa","oa","oa","oa","oa","oa","oa","oa","oa","ws","o","w","we","we","we","w","w","w","w","w","w","oa","oa","oa","w",],
["we","we","w","oa","oa","oa","oa","oa","oa","oa","w","w","w","w","w","o","w","we","we","we","we","we","we","we","we","w","oa","oa","oa","w",],
["we","we","w","w","ws","w","w","w","w","w","w","we","we","we","w","o","w","we","we","we","we","we","w","w","w","w","oa","oa","oa","w",],
["we","we","w","o","o","op","o","o","o","o","w","we","we","w","w","ud","w","w","we","we","we","we","w","o","ow","ud","oa","oa","oa","w",],
["we","we","w","o","o","op","o","o","o","o","w","we","we","w","oa","oa","oa","w","we","we","we","we","w","o","w","w","w","w","oa","w",],
["we","we","w","o","o","op","o","o","o","o","w","we","we","w","oa","oa","oa","w","we","we","we","we","w","o","w","we","we","w","oa","w",],
["we","we","w","w","w","w","w","o","w","w","w","we","we","w","oa","oa","oa","w","we","we","we","we","w","o","w","we","we","w","oa","w",],
["we","we","we","we","we","we","w","o","w","we","we","we","we","w","w","ud","w","w","we","we","we","we","w","o","w","we","we","w","w","w",],
["we","we","we","we","we","we","w","o","w","we","we","we","we","we","w","o","w","we","we","we","we","we","w","ow","w","we","we","we","we","we",],
["we","we","we","we","we","w","w","ud","w","w","w","w","we","we","w","o","w","we","we","w","w","w","w","ud","w","w","we","we","we","we",],
["we","we","we","we","we","w","o","o","o","o","o","w","w","w","w","o","w","w","w","w","o","o","o","o","o","w","we","we","we","we",],
["we","we","we","we","we","w","o","w","w","w","o","o","o","o","o","o","o","o","o","o","o","w","w","w","o","w","we","we","we","we",],
["we","we","we","we","we","w","o","w","we","w","o","w","w","w","w","w","w","w","w","w","o","w","we","w","o","w","we","we","we","we",],
["we","we","we","we","we","w","o","w","w","w","o","w","oa","oa","w","oa","w","oa","oa","w","o","w","w","w","o","w","we","we","we","we",],
["we","we","we","we","we","w","o","o","o","o","o","ud","oa","oa","oa","oa","oa","oa","oa","ud","o","o","o","o","o","w","we","we","we","we",],
["we","we","we","we","we","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","we","we","we","we",],
["we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we","we",],

         ];
   
   var teleportX = 400;
   var teleportY = -50;
   var moduls = 5;

   var isVisited = localStorage.getItem('level'+ tempLocation);
   console.log("level is visited: " + isVisited);

   if(isVisited==1){
    monster.style.display="none";
    monster2.style.display="none";
    monsterPortal.style.display="none";
    controlPanel.style.backgroundImage='URL("IMG/controlPanelOFF.jpg")';
   
        try{
            off();
            turelActive=0;
            bullet.style.display="none";
            toggle=0;
            
            }
        catch{

            }
            
   }
   else{
      // alert("Find all the alarm-modules, otherwise you will die from nerve gas. you have 150 seconds!");
   }