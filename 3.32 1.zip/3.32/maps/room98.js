      var map =[
           ["we","we","we","we","we","we","we","we","we","w","w","w","w","w","w","w","w","w","w","we","we","we","we","we","w","w","w","w","w","w",],
["we","we","we","we","we","we","we","we","we","w","o","o","o","w","w","oa","o","o","w","we","we","we","we","we","w","flu","flu","flu","flu","w",],
["we","we","we","we","we","we","we","we","we","w","o","o","o","w","w","o","o","o","w","we","we","we","we","we","w","flu","flu","flu","flu","w",],
["we","we","we","we","we","we","we","we","we","w","o","o","o","w","w","o","o","o","w","we","we","we","we","we","w","flu","flu","flu","flu","w",],
["we","we","we","we","we","we","we","we","we","w","o","o","oa","w","w","o","o","o","w","we","we","we","we","we","w","flu","flu","flu","flu","w",],
["we","we","we","we","w","w","w","w","we","w","w","o","w","w","w","w","o","w","w","we","we","we","we","we","w","flu","flu","flu","flu","w",],
["we","we","we","w","w","oa","o","w","we","w","oa","o","o","o","o","o","o","o","w","we","we","we","we","we","w","flu","flu","flu","flu","w",],
["we","we","we","w","o","o","o","w","we","w","oa","o","o","o","o","o","o","o","w","we","we","w","w","w","w","w","w","flu","flu","w",],
["we","we","we","w","o","o","o","w","w","w","o","o","oa","o","o","o","o","oa","w","we","we","w","flu","flu","flu","flu","flu","flu","flu","w",],
["we","we","we","w","o","o","o","o","o","o","o","o","o","o","o","o","o","o","w","we","we","w","flu","flu","flu","flu","flu","flu","flu","w",],
["we","we","we","w","o","o","o","w","w","w","o","o","o","o","o","o","o","o","w","we","we","w","flu","flu","flu","flu","flu","flu","flu","w",],
["we","we","we","w","w","w","w","w","o","o","o","o","o","o","o","o","o","o","w","we","we","w","flu","flu","flu","flu","flu","flu","flu","w",],
["we","we","we","w","o","o","o","o","o","w","o","o","o","oa","o","oa","o","o","w","we","we","w","w","w","w","w","w","flu","flu","w",],
["we","we","we","w","o","o","o","w","w","w","oa","o","o","o","o","o","o","o","w","we","we","we","we","we","we","we","w","flu","flu","w",],
["we","we","we","w","o","o","o","w","we","w","w","w","w","o","o","w","w","w","w","we","we","we","we","we","we","we","w","flu","flu","w",],
["we","we","we","w","o","o","o","w","we","we","we","we","w","o","o","w","we","we","we","we","we","we","we","we","we","we","w","flu","flu","w",],
["we","we","we","w","w","w","oa","w","we","we","we","we","w","o","o","w","we","we","we","we","we","we","we","we","we","we","w","flu","flu","w",],
["we","we","we","we","we","w","w","w","we","we","we","we","w","o","o","w","we","we","we","we","we","we","we","we","we","we","w","flu","flu","w",],
["we","we","we","we","we","we","we","we","we","we","we","we","w","o","o","w","we","we","we","we","we","we","we","we","we","we","w","flu","flu","w",],
["we","we","we","we","we","we","we","we","we","we","we","w","w","o","o","w","w","we","we","we","w","w","w","w","w","w","w","flu","flu","w",],
["we","we","we","we","we","we","we","we","we","we","we","w","o","o","o","oa","w","we","we","we","w","flf","flf","flf","flf","flf","flf","flf","flf","w",],
["we","we","we","we","we","we","we","we","we","we","we","w","o","o","o","o","w","we","we","we","w","flf","flf","flf","flf","flf","flf","flf","flf","w",],
["we","we","we","we","we","we","we","we","we","we","we","w","o","o","o","o","w","we","we","we","w","b","b","b","flf","flf","flf","flf","flf","w",],
["we","we","we","we","we","we","we","we","we","we","we","w","o","o","o","o","w","we","we","we","w","b","w","b","flf","flf","flf","flf","flf","w",],
["we","we","we","we","we","we","we","we","we","we","we","w","oa","o","o","o","w","we","we","we","w","b","b","b","flf","flf","b","b","b","w",],
["we","we","we","we","we","we","we","we","we","we","we","w","o","o","o","o","w","w","w","w","w","flf","flf","flf","flf","flf","b","w","b","w",],
["we","we","we","we","we","we","we","we","we","we","we","w","o","o","oa","o","o","o","o","o","w","flf","flf","flf","flf","flf","b","b","b","w",],
["we","we","we","we","we","we","we","we","we","we","we","w","o","o","oa","o","o","o","o","o","ws","flf","flf","flf","flf","flf","flf","flf","flf","w",],
["we","we","we","we","we","we","we","we","we","we","we","w","o","o","o","o","o","o","oa","oa","w","flf","flf","flf","flf","flf","flf","flf","flf","w",],
["we","we","we","we","we","we","we","we","we","we","we","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",]
         ];
   
   var teleportX = 0;
   var teleportY = 0;
   var moduls = 5;


   var isVisited = localStorage.getItem('level'+ tempLocation);
   console.log("level is visited: " + isVisited);

   if(isVisited==1){
    monster.style.display="none";
    monster2.style.display="none";
    monsterPortal.style.display="none";
    controlPanel.style.backgroundImage='URL("IMG/controlPanelOFF.jpg")';
        try{
            off();
            turelActive=0;
            bullet.style.display="none";
            toggle=0;
            
            }
        catch{

            }
            
   }

