   var map =[

       ["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",],
       ["w","o","o","o","w","ow","o","oa","o","oa","o","oa","o","oa","o","ow","w","ow","o","oa","o","oa","o","oa","o","oa","o","oa","o","w",],
       ["w","o","o","o","ud","ow","o","o","o","o","o","o","o","o","o","ow","ud","ow","o","o","o","o","o","o","o","o","o","o","o","w",],
       ["w","o","o","o","w","ow","o","oa","o","oa","o","oa","o","oa","o","ow","w","ow","o","oa","o","oa","o","oa","o","oa","ow","ow","ow","w",],
       ["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","ud","w","w",],
       ["w","o","op","o","op","o","op","o","w","oa","o","oa","o","oa","o","oa","w","o","wc","o","o","o","wc","o","o","o","wc","o","o","w",],
       ["w","o","o","o","o","o","o","o","ud","o","o","o","o","o","o","o","ud","o","wc","o","wc","o","wc","o","wc","o","wc","o","o","w",],
       ["w","o","op","o","op","o","op","o","w","oa","o","oa","o","oa","o","oa","w","o","o","o","wc","o","o","o","wc","o","o","o","o","w",],
       ["w","w","ud","w","w","w","w","w","w","w","w","w","ws","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",],
       ["w","bg","o","bg","gr","gr","gr","gr","w","as","asv","as","asv","as","asv","as","asv","as","asv","as","w","o","o","w","as","asv","as","asv","as","w",],
       ["w","gr","o","gr","gr","gr","gr","gr","w","as","asv","as","asv","as","asv","as","asv","as","asv","as","w","o","o","w","as","asv","as","asv","as","w",],
       ["w","gr","o","gr","gr","gr","gr","gr","w","as","as","as","as","as","as","as","as","as","as","as","w","w","ud","w","as","as","as","as","as","w",],
       ["w","gr","o","o","o","o","o","o","o","as","as","as","as","as","as","as","as","as","as","as","b","as","as","b","as","as","as","as","as","w",],
       ["w","gr","gr","gr","gr","gr","gr","gr","w","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","as","w",],
       ["w","w","w","w","w","w","w","w","w","as","as","ash","ash","ash","ash","ash","ash","ash","ash","ash","ash","ash","as","as","as","as","as","ash","ash","w",],
       ["w","as","as","as","as","as","as","as","as","as","asv","as","as","as","as","as","as","as","as","as","as","as","asv","as","as","as","as","as","as","w",],
       ["w","as","as","as","as","as","as","as","as","as","asv","as","w","w","w","w","w","w","w","w","w","as","asv","as","as","as","as","ash","ash","w",],
       ["w","ash","ash","as","as","as","as","as","as","as","asv","as","w","o","o","o","o","o","o","o","w","as","asv","as","as","as","as","as","as","w",],
       ["w","as","as","as","as","as","as","ash","ash","ash","as","as","w","o","oa","o","oa","o","oa","o","w","as","asv","as","as","as","as","ash","ash","w",],
       ["w","ash","ash","as","as","as","asv","as","as","as","as","as","w","w","w","w","w","w","w","ud","w","as","asv","as","as","as","as","as","as","w",],
       ["w","as","as","as","as","as","asv","as","as","as","as","as","w","flf","oa","flf","flf","flf","oa","flf","w","b","as","b","w","w","w","w","w","w",],
       ["w","ash","ash","as","as","as","asv","as","as","as","ash","ash","w","flf","flf","flf","flf","flf","flf","flf","w","w","ud","w","w","w","o","o","o","w",],
       ["w","as","as","as","as","as","asv","as","as","as","as","as","w","flf","ow","ow","ow","ow","ow","flf","flf","w","ow","w","ow","ud","o","o","o","w",],
       ["w","ash","ash","as","as","as","asv","as","as","as","ash","ash","w","flf","ow","flu","flu","flu","ow","flf","flf","w","ow","w","ow","w","flf","flf","flf","w",],
       ["w","as","as","as","as","as","asv","as","as","as","as","as","w","se","ow","flu","flu","flu","ow","flf","flf","w","ow","ow","ow","w","flf","flf","flf","w",],
       ["w","ash","ash","as","as","as","asv","as","as","as","ash","ash","w","flf","ow","flu","flu","flu","ow","flf","flf","w","w","w","w","w","flf","flf","flf","w",],
       ["w","as","as","as","as","as","asv","as","as","as","as","as","w","flf","ow","ow","ow","ow","ow","flf","flf","w","flf","flf","flf","flf","flf","flf","flf","w",],
       ["w","ash","ash","as","as","as","asv","as","as","as","ash","ash","w","flf","flf","flf","flf","flf","flf","flf","flf","w","flf","flf","flf","flf","flf","flf","flf","w",],
       ["w","as","as","as","as","as","as","as","as","as","as","as","w","flf","oa","flf","flf","flf","oa","flf","flf","ud","flf","flf","flf","flf","flf","flf","flf","w",],
       ["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",]
                ];
   
   var teleportX = 400;
   var teleportY = -50;
   var moduls = 5;

