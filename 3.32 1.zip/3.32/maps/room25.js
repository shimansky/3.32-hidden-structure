   var map =[

     ["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",],
["w","w","w","w","w","b","b","b","b","b","b","b","b","w","w","w","w","w","w","w","oa","w","w","ow","ow","ow","o","w","w","w",],
["w","w","w","w","b","b","gr","gr","gr","gr","gr","gr","b","b","b","w","w","w","w","w","oa","o","w","o","gr","o","o","w","w","w",],
["w","w","w","ow","b","gr","gr","vw","vw","vw","vw","gr","ow","b","b","w","w","w","w","w","oa","o","o","gr","gr","gr","o","o","w","w",],
["w","w","oa","oa","b","b","vw","vw","vw","vw","vw","gr","ow","b","b","w","w","w","w","o","o","oa","gr","gr","gr","bg","bg","o","oa","w",],
["w","w","oa","ow","b","gr","vw","vw","vw","vw","vw","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","bg","oa","oa","w",],
["w","w","w","ow","b","gr","gr","vw","vw","vw","gr","gr","bg","bg","bg","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","bg","o","o","w",],
["w","w","w","ow","b","ow","gr","gr","gr","gr","gr","ow","b","b","b","o","gr","gr","gr","gr","gr","o","o","gr","gr","gr","o","w","w","w",],
["w","w","w","w","w","b","b","gr","gr","bg","ow","b","b","w","w","w","o","o","gr","gr","o","o","gr","gr","gr","gr","o","o","w","w",],
["w","w","w","w","w","b","b","gr","gr","bg","b","w","w","w","w","gr","gr","gr","gr","o","o","w","gr","gr","gr","gr","gr","o","o","w",],
["w","w","w","w","w","w","b","gr","gr","bg","b","w","w","gr","gr","gr","b","o","o","o","w","w","gr","gr","gr","gr","gr","gr","oa","w",],
["w","w","w","w","w","w","w","b","gr","gr","b","w","gr","gr","b","w","w","b","b","o","w","w","w","gr","gr","gr","gr","bg","o","w",],
["w","w","w","w","w","w","w","b","gr","gr","gr","gr","gr","bg","w","w","w","w","w","w","w","w","o","gr","gr","gr","gr","bg","oa","w",],
["w","w","w","w","w","w","w","b","gr","gr","gr","bg","bg","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",],
["w","w","w","w","w","w","o","gr","gr","gr","bg","bg","bg","w","w","w","o","o","oa","oa","o","w","w","w","w","w","w","w","w","w",],
["w","w","o","o","o","o","gr","gr","gr","bg","bg","bg","w","w","w","o","gr","gr","gr","o","bg","bg","bg","o","gr","gr","gr","o","b","w",],
["w","o","gr","gr","oa","gr","gr","gr","gr","o","w","w","w","w","o","gr","gr","gr","gr","gr","o","bg","bg","gr","gr","gr","gr","bg","b","w",],
["w","oa","gr","gr","gr","gr","gr","gr","o","w","w","w","w","w","w","w","w","w","w","gr","gr","gr","gr","gr","gr","gr","gr","bg","o","w",],
["w","oa","bg","gr","gr","gr","gr","gr","oa","w","w","w","snk","tol","w","flu","flu","flu","ud","gr","o","o","gr","gr","gr","gr","gr","o","w","w",],
["w","o","bg","bg","gr","gr","gr","gr","oa","chain","o","w","flu","flu","w","flu","flu","flu","w","oa","o","o","o","gr","gr","gr","ow","o","w","w",],
["w","b","b","bg","gr","gr","bg","gr","gr","chain","ow","w","w","ud","w","flu","flu","flu","w","oa","oa","bg","bg","gr","gr","gr","ow","w","w","w",],
["w","b","b","o","gr","gr","bg","bg","gr","chain","ow","ud","flu","flu","flu","flu","flu","flu","w","w","w","o","gr","gr","gr","gr","ow","w","w","w",],
["w","w","w","o","o","o","gr","gr","gr","chain","ow","w","flu","flu","flu","flu","flu","flu","w","w","o","gr","gr","gr","gr","gr","gr","o","o","w",],
["w","w","w","w","oa","oa","o","o","oa","chain","o","w","w","w","w","w","w","w","w","o","gr","gr","gr","gr","gr","gr","b","b","o","w",],
["w","w","w","w","w","w","o","o","o","chain","o","oa","w","w","w","w","o","o","gr","gr","gr","gr","gr","gr","gr","gr","gr","bg","b","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","o","o","gr","gr","gr","gr","gr","gr","gr","gr","b","b","b","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","gr","gr","o","o","gr","gr","gr","gr","bg","bg","b","b","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","o","o","gr","gr","gr","o","o","o","gr","bg","bg","bg","o","b","b","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","o","o","ow","ow","ow","o","o","w","o","o","o","o","o","o","o","b","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",]                ];
   
   var teleportX = 400;
   var teleportY = -50;
   var moduls = 5;

