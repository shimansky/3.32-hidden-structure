   var map =[

       ["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",],
["w","gr","gr","gr","gr","gr","gr","bg","w","gr","gr","gr","gr","gr","bg","w","bg","gr","gr","gr","gr","gr","gr","bg","w","gr","bg","gr","gr","w",],
["w","bg","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","w","w","gr","gr","bg","gr","gr","gr","gr","w","gr","gr","gr","gr","w",],
["w","bg","bg","gr","gr","gr","gr","gr","w","gr","gr","gr","gr","gr","gr","bg","gr","gr","gr","gr","bg","bg","gr","gr","gr","gr","gr","bg","gr","w",],
["w","gr","gr","gr","gr","gr","bg","gr","w","w","w","w","gr","gr","gr","gr","gr","gr","gr","gr","bg","gr","gr","gr","w","bg","gr","gr","gr","w",],
["w","gr","gr","w","gr","gr","gr","bg","w","ow","ow","ws","gr","gr","gr","gr","gr","w","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","gr","w",],
["w","w","w","w","w","w","w","w","w","ud","w","w","w","gr","gr","gr","bg","w","gr","bg","bg","gr","gr","bg","w","gr","gr","bg","gr","w",],
["w","oa","oa","oa","oa","oa","oa","oa","oa","oa","oa","oa","w","ud","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",],
["w","wc","o","o","o","o","oa","o","oa","o","oa","o","w","oa","oa","oa","oa","ud","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","w",],
["w","wc","o","o","o","o","oa","o","op","o","op","o","w","oa","oa","oa","oa","w","flf","flf","flf","flf","flf","flf","w","w","w","flf","flf","w",],
["w","wc","wc","o","oa","oa","oa","o","op","o","op","o","w","oa","oa","oa","oa","ud","flf","flf","flf","flf","flf","flf","w","flf","flf","flf","flf","w",],
["w","o","o","o","oa","o","o","o","oa","o","oa","o","w","oa","oa","oa","oa","w","flf","flf","w","w","flf","flf","flf","flf","flf","flf","flf","w",],
["w","o","o","o","oa","o","wc","wc","w","w","ud","w","w","w","w","w","w","w","flf","flf","w","flf","flf","flf","flf","flf","flf","flf","flf","w",],
["w","o","wc","o","oa","o","o","o","w","o","o","o","w","o","o","o","o","w","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","w",],
["w","wc","wc","o","oa","o","o","o","w","o","o","o","w","o","o","o","o","w","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","w",],
["w","wc","o","o","oa","o","wc","o","w","w","w","w","w","w","ws","w","w","w","w","w","w","w","w","w","w","w","flf","flf","flf","w",],
["w","o","o","o","oa","wc","wc","wc","w","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","w","o","o","ud","flf","flf","flf","w",],
["w","o","o","wc","oa","o","o","o","w","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","w","o","o","w","flf","flf","flf","w",],
["w","wc","wc","wc","oa","o","o","o","w","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","flf","w","o","o","w","flf","flf","flf","w",],
["w","wc","o","o","oa","wc","wc","o","w","flf","flf","flf","w","w","w","w","w","w","w","w","flf","flf","w","o","o","w","flf","flf","flf","w",],
["w","o","o","o","oa","wc","o","o","w","flf","flf","flf","w","o","o","o","o","o","o","w","flf","flf","w","o","o","w","flf","flf","flf","w",],
["w","wc","o","o","oa","o","o","wc","w","flf","flf","flf","w","o","o","oa","o","oa","o","w","flf","flf","w","o","o","w","flf","flf","flf","w",],
["w","wc","o","o","oa","o","wc","wc","w","flf","flf","flf","w","o","o","op","o","op","o","ud","flf","flf","w","o","o","w","flf","flf","flf","w",],
["w","wc","wc","o","oa","o","wc","w","w","oa","oa","oa","w","w","o","op","o","op","o","w","flf","flf","w","o","o","w","flf","flf","flf","w",],
["w","o","o","o","oa","o","o","w","bg","gr","gr","gr","bg","w","o","oa","o","oa","o","w","flf","flf","w","o","o","w","flf","flf","flf","w",],
["w","wc","o","o","oa","o","o","w","gr","gr","gr","gr","gr","w","o","o","o","o","o","w","flf","flf","w","o","o","w","flf","flf","flf","w",],
["w","wc","wc","o","oa","wc","o","w","bg","gr","gr","gr","bg","w","w","w","w","w","w","w","flf","flf","w","w","w","w","flf","flf","flf","w",],
["w","wc","o","oa","oa","wc","o","w","gr","gr","gr","gr","gr","w","o","o","o","o","o","ud","flf","flf","flf","flf","flf","flf","flf","flf","flf","w",],
["w","o","o","o","o","wc","o","w","bg","gr","ow","gr","bg","w","o","o","o","o","o","w","flf","flf","flf","flf","flf","flf","flf","flf","flf","w",],
["w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w","w",]
                ];
   
   var teleportX = 400;
   var teleportY = -50;
   var moduls = 5;

