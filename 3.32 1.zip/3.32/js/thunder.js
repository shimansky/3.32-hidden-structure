var thunder = new Audio("SOUND/thunder.mp3");
var startTime = 27000;
var lightingStart = 3000;
var lightingEnd = lightingStart + 100;

function thunderStrike() {
	thunder.play();
	setTimeout(()=>{game.style.filter = "none"},lightingEnd);
	setTimeout(()=>{game.style.filter = "brightness(5)"},lightingStart);
	
	console.log("lightingStart :" + lightingStart + ", lightingEnd :" + lightingEnd);
}

setTimeout(thunderStrike, startTime);