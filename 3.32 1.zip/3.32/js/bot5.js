var bot5LeftXDistance=-10;
var bot5RightXDistance=10;
var bot5UpYDistance=10;
var bot5DownYDistance=-10;
var temp2;
var vertical2;
var rand2;
var botLife2=250;
var toggle=1;
var enemyKillCounter5 = rand=Math.floor(Math.random() * (6 - 0)) + 0;
enemy2=document.getElementById('monster2');

enemy2.addEventListener("mousedown", ()=>{
      if(playerCanShoot==1){
        botLife2=botLife2-attack;
        sensorPlayerAttack();
        }
});

// var m2 = enemy2.getBoundingClientRect();

enemy2.onclick=shootToEnemy2;

var monsterDied = new Audio('SOUND/monsterDied.mp3');
var monsterPortalSound = new Audio('SOUND/monsterPortal.mp3');

function bot5_get_coordinates(unit){
  var m2 = enemy2.getBoundingClientRect();
 
  // определение имени класса элемента "слева" от юнита
left_empty = document.elementFromPoint((unit.right-55),(unit.bottom-5)).className;
objLeft =  document.elementFromPoint((unit.right-55),(unit.bottom-5));
if ( left_empty!="world" && left_empty!="we" && left_empty!="person" && left_empty!="w" && left_empty!="wc"&& left_empty!="ws" && left_empty!="wp" &&left_empty!="locked_door_white"&&left_empty!="locked_door_black" ) {
 leftTemp=1;
 if(left_empty=="irSensor"){
  objLeft.className = "deadMonster";
  enemy2.style.filter = "url(#yellow-outline)";
  setTimeout(function(){enemy2.style.filter = "none"},200);
  botLife2-=50;
  plasmaGunShoot.play();
  
}
}
else{
  leftTemp=0;
}

// определение имени класса элемента "справа" от юнита
right_empty  = document.elementFromPoint((unit.right+5),(unit.bottom-5)).className;
objRight = document.elementFromPoint((unit.right+5),(unit.bottom-5));
if ( right_empty!="world" && right_empty!="we" && right_empty!="person" && right_empty!="w" && right_empty!="wc"&& right_empty!="ws" && right_empty!="wp" &&right_empty!="locked_door_white"&&right_empty!="locked_door_black" ) {
 rightTemp=1;
 if(right_empty=="irSensor"){
  objRight.className = "deadMonster";
  enemy2.style.filter = "url(#yellow-outline)";
  setTimeout(function(){enemy2.style.filter = "none"},200);
  botLife2-=50;
  plasmaGunShoot.play();
}
}
else{
  rightTemp=0;
}

// определение имени класса элемента "снизу" от юнита
down_empty = document.elementFromPoint((unit.right-25),(unit.bottom+5)).className;
objDown = document.elementFromPoint((unit.right-25),(unit.bottom+5));
if ( down_empty!="world" && down_empty!="we" && down_empty!="person" && down_empty!="w" && down_empty!="wc"&& down_empty!="ws" && down_empty!="wp" &&down_empty!="locked_door_white"&&down_empty!="locked_door_black" ) {
 downTemp=1;
 if(down_empty=="irSensor"){
  objDown.className = "deadMonster";
  enemy2.style.filter = "url(#yellow-outline)";
  setTimeout(function(){enemy2.style.filter = "none"},200);
  botLife2-=50;
  plasmaGunShoot.play();
}
}
else{
  downTemp=0;
}

// определение имени класса элемента "сверху" от юнита
up_empty = document.elementFromPoint((unit.right-25),(unit.bottom-55)).className;
objUp = document.elementFromPoint((unit.right-25),(unit.bottom-55));
if ( up_empty!="world" && up_empty!="we" && up_empty!="person" && up_empty!="w" && up_empty!="wc"&& up_empty!="ws" && up_empty!="wp" &&up_empty!="locked_door_white"&&up_empty!="locked_door_black" ) {
 upTemp=1;
  if(up_empty=="irSensor"){
  objUp.className = "deadMonster";
  enemy2.style.filter = "url(#yellow-outline)";
  setTimeout(function(){enemy2.style.filter = "none"},200);
  botLife2-=50;
  plasmaGunShoot.play();
}
}
else{
  upTemp=0;
}
}

// блок функций анимации бота
enemy2.moveRight=function(distance) {
    this.innerHTML=botLife2;
  var m2 = enemy2.getBoundingClientRect();
  bot5_get_coordinates(m2);
  this.style.backgroundImage='URL("IMG/monsterThongle_r.gif")';
if (rightTemp==1) {
  temp2=temp2+distance;
  this.style.left = temp2 + 'px';
    }
}
enemy2.moveLeft=function(distance) {
    this.innerHTML=botLife2;
  var m2 = enemy2.getBoundingClientRect();
  bot5_get_coordinates(m2);
  this.style.backgroundImage='URL("IMG/monsterThongle_l.gif")';
if (leftTemp==1) {
  temp2=temp2+distance;
  this.style.left = temp2 + 'px';
    }
}
enemy2.moveUp=function(distance) {
    this.innerHTML=botLife2;
  var m2 = enemy2.getBoundingClientRect();
  bot5_get_coordinates(m2);
  this.style.backgroundImage='URL("IMG/monsterThongle_r.gif")';
if (upTemp==1) { 
  vertical2=vertical2+distance;
  this.style.bottom = vertical2 + 'px';
    }
}
enemy2.moveDown=function(distance) {
    this.innerHTML=botLife2;
  var m2 = enemy2.getBoundingClientRect();
  bot5_get_coordinates(m2);
  this.style.backgroundImage='URL("IMG/monsterThongle_l.gif")';
if (downTemp==1) {
  vertical2=vertical2+distance;
    }
}


function showEnemy2(){
  enemy2.style.display="inline-block";
  monsterPortalSound.play();
}

function insertDeadBot2Body() {
  var deadMonster = document.createElement('div');
    deadMonster.className = "deadMonster";
    deadMonster.style.left=enemy2.style.left;
    deadMonster.style.bottom=enemy2.style.bottom; 
    game.append(deadMonster);
}



// ИИ для бота
function botMove2(){
  if(botLife2<0){
    monsterDied.play();
       if(toggle==0){
         insertDeadBot2Body();
         clearInterval(timerId2);
        enemy2.style.display="none";
       }
 else{
  // вставка тела мертвого монстра начало
   insertDeadBot2Body();
  // вставка тела мертвого монстра конец
    enemy2.style.display="none";
           enemyKillCounter5-=1;
           console.log( "enemyKillCounter " + enemyKillCounter5);
           if (enemyKillCounter5>=0) {
               setTimeout(showEnemy2, (rand2=Math.floor(Math.random() * (6 - 0)) + 0)*1000);
               botLife2 = 250;
               monsterPortal.style.left=enemy2.style.left;
               monsterPortal.style.bottom=enemy2.style.bottom;
               portaltemp=+monsterPortal.style.left.toString().slice(0, -2);
               portalvertical=+monsterPortal.style.bottom.toString().slice(0, -2);
               temp2 = portaltemp;
               vertical2 = portalvertical;
               enemy2.style.left = temp2 + 'px';
               enemy2.style.bottom = vertical2 + 'px';
               // monsterPortal.style.left=player.style.left;
               // monsterPortal.style.bottom=player.style.bottom;
           }
           else{
               insertDeadBot2Body();
               clearInterval(timerId2);
               enemy2.style.display="none";
           }
    
  }
  }
  try{
   var p = figure.getBoundingClientRect();
   var m2 = enemy2.getBoundingClientRect();

    // отслеживание столкновений с ботом
 if( ( (p.bottom-m2.bottom)<=50 && (p.bottom-m2.bottom)>=-50 ) && ( (p.right-m2.right)<=50 && (p.right-m2.right)>=-50 )) {
  if(life<0){
  panel.innerHTML="life: "+ life;;
  showMassege();
  window.navigator.vibrate([100,100,30,100,100,30,100,100,30]);
  setTimeout(exit, 5000);
 
}
else{
  life-=2;
  localStorage.setItem('life', life);
  panel.innerHTML="life: " + life;
  // figure.innerHTML="<span>"+life+"</span>";
  window.navigator.vibrate(50);
  monsterAttack.play();

 }
}


    if(p.right-m2.right<200 && p.right-m2.right>0){
      enemy2.moveRight(bot5RightXDistance);
    }
    
     if(p.right-m2.right>-200 && p.right-m2.right<0){
      enemy2.moveLeft(bot5LeftXDistance);
    }
    
      if(p.bottom-m2.bottom<200 && p.bottom-m2.bottom>0){
      enemy2.moveDown(bot5DownYDistance);
    }
    
     if(p.bottom-m2.bottom>-200 && p.bottom-m2.bottom<0){
      enemy2.moveUp(bot5UpYDistance);
    }

    else{

    
    
    if(rand2==0){
      enemy2.moveRight(bot5RightXDistance);
 
      
    }
    else
    if(rand2==1){
      enemy2.moveLeft(bot5LeftXDistance);
      
      
    }
    else
    if(rand2==2){
      enemy2.moveUp(bot5UpYDistance);
      
      
    }
    else
    if(rand2==3){
      enemy2.moveDown(bot5DownYDistance);
      
      
    }
}
}
catch(e){
  
}

}


function createEnemySoul2(){
    let soul2 = document.createElement('div');
    soul2.className = 'soul-thing';
    game.appendChild(soul2);
    soul2.style.left = enemy2.style.left;
    soul2.style.bottom = enemy2.style.bottom;
    setTimeout(function(){
      soul2.remove();
    },500);
    }

function shootToEnemy2(){

  if(cells>0 || sCells>0 || plCells>0){
    if(inTeleportation==0){
    if (flagInHit==0) {
          flagInHit=1
          playerHit();
       }
      }

    let patron2 = document.createElement('div');
    patron2.className = 'patron';
    game.appendChild(patron2);
    patron2.style.left = figure.style.left;
    patron2.style.bottom = figure.style.bottom;
    setTimeout(function(){
      patron2.style.left = enemy2.style.left;
      patron2.style.bottom = enemy2.style.bottom;
    },100);
    setTimeout(function(){
      patron2.remove();
    },500);
    console.log(cells, sCells, plCells);
    }

  }

setInterval(function(){rand2=Math.floor(Math.random() * (6 - 0)) + 0},2000);