var ambient = new Audio('SOUND/2nd level ambient.mp3');
ambient.loop = true;