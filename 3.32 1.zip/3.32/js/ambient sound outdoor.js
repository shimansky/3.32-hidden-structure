var ambient = new Audio('SOUND/outdoor ambient.mp3');
ambient.loop = true;