 class Enemy {

	constructor(name, className, x, y) {
		this.name = name;
		this.name = document.createElement('div');
		game.appendChild(this.name);
		this.name.className = className;
		this.name.style.left = x + "px";
		this.name.style.bottom = y + "px";
		this.name.temp = x;
		this.name.vertical = y;
		this.name.toggle = 1;
		this.life = Math.floor(Math.random() * (200 - 10)) + 10;
		this.scores = this.life;
		this.damage = Math.floor(Math.random() * (localStorage.getItem('difficult') - localStorage.getItem('minDifficult')))  +  parseInt(localStorage.getItem('minDifficult'), 10);
		this.name.left_empty = " ";
		this.name.right_empty = " ";
		this.name.down_empty = " ";
		this.name.up_empty = " ";
		this.name.speed = 20;
		this.speedAlienInterval = 200;
		this.direction = 0;
		this.leftTemp = 0;
		this.rightTemp = 0;
		this.upTemp = 0;
		this.downTemp = 0;
		this.alienCounter = 0;
		this.alienMaximum = 2;
		this.objLeft;
		this.objRight;
		this.objDown;
		this.objUp;
		this.name.killSelf = ()=> {
					try{
	      		alienKilledCounter-=1;
	      		scores+=this.scores;
   					panel.innerHTML="life: " + life + " scores: " + scores;
	      	}catch{

	      	}
					this.insertDeadBotBody();
					this.createThing();
					this.name.remove();
					monsterDied.play();
					}
		this.name.get_coordinates =  (unit)=> {

				try{

			
		 // определение имени класса элемента "слева" от юнита
		 	this.objLeft = document.elementFromPoint((unit.right-55),(unit.bottom-5));
		 	if(this.objLeft==null){
		 		this.leftTemp = 0;
		 	}else{
			this.name.left_empty = document.elementFromPoint((unit.right-55),(unit.bottom-5)).className;
			if ( this.name.left_empty!="tab" && this.name.left_empty!="interface" && this.name.left_empty!="monsterthongle" && this.name.left_empty!="monstersnake" && this.name.left_empty!="monsterblob" && this.name.left_empty!="alien" && this.name.left_empty!="world" && this.name.left_empty!="we" && this.name.left_empty!="person" && this.name.left_empty!="w" && this.name.left_empty!="wc"&& this.name.left_empty!="ws" && this.name.left_empty!="wp" &&this.name.left_empty!="locked_door_white"&&this.name.left_empty!="locked_door_black" ) {
			this.leftTemp=1;
				if(this.name.left_empty == "irSensor"){
	  			this.objLeft.className = "explode";
	  			this.life-=50;
	  			plasmaGunShoot.play();
					}
				}else{
					this.leftTemp = 0;
				}
			}

		
		

		
		// определение имени класса элемента "справа" от юнита
			this.objRight = document.elementFromPoint((unit.right+5),(unit.bottom-5));
			if(this.objRight==null){
				this.rightTemp = 0;
			}else{
			this.name.right_empty  = document.elementFromPoint((unit.right+5),(unit.bottom-5)).className;
			if ( this.name.right_empty!="tab" && this.name.right_empty!="interface" && this.name.right_empty!="monsterthongle" && this.name.right_empty!="monstersnake" && this.name.right_empty!="monsterblob" && this.name.right_empty!="alien" && this.name.right_empty!="world" && this.name.right_empty!="we" && this.name.right_empty!="person" && this.name.right_empty!="w" && this.name.right_empty!="wc"&& this.name.right_empty!="ws" && this.name.right_empty!="wp" &&this.name.right_empty!="locked_door_white"&&this.name.right_empty!="locked_door_black" ) {
			 this.rightTemp=1;
				if(this.name.right_empty == "irSensor"){
	  			this.objRight.className = "expole";
	  			this.life-=50;
	  			plasmaGunShoot.play();
					}
				}else{
					this.rightTemp = 0;
				}
			}
		

	
		// определение имени класса элемента "снизу" от юнита
			this.objDown = document.elementFromPoint((unit.right-25),(unit.bottom+5));
			if(this.objDown==null){
				this.downTemp = 0;
			}else{
			this.name.down_empty = document.elementFromPoint((unit.right-25),(unit.bottom+5)).className;
			if ( this.name.down_empty!="tab" && this.name.down_empty!="interface" && this.name.down_empty!="monsterthongle" && this.name.down_empty!="monstersnake" && this.name.down_empty!="monsterblob" && this.name.down_empty!="alien" && this.name.down_empty!="world" && this.name.down_empty!="we" && this.name.down_empty!="person" && this.name.down_empty!="w" && this.name.down_empty!="wc"&& this.name.down_empty!="ws" && this.name.down_empty!="wp" &&this.name.down_empty!="locked_door_white"&&this.name.down_empty!="locked_door_black" ) {
			this.downTemp=1;
				if(this.name.down_empty == "irSensor"){
	  			this.objDown.className = "explode";
	  			this.life-=50;
	  			plasmaGunShoot.play();
					}
				}else{
					this.downTemp = 0;
				}
			}
			
		

		
		// определение имени класса элемента "сверху" от юнита
			this.objUp = document.elementFromPoint((unit.right-25),(unit.bottom-55));
			if(this.objUp==null){
				this.upTemp = 0;
			}else{
			this.name.up_empty = document.elementFromPoint((unit.right-25),(unit.bottom-55)).className;
			if ( this.name.up_empty!="tab" && this.name.up_empty!="interface" && this.name.up_empty!="monsterthongle" && this.name.up_empty!="monstersnake" && this.name.up_empty!="monsterblob" && this.name.up_empty!="alien" && this.name.up_empty!="world" && this.name.up_empty!="we" && this.name.up_empty!="person" && this.name.up_empty!="w" && this.name.up_empty!="wc"&& this.name.up_empty!="ws" && this.name.up_empty!="wp" &&this.name.up_empty!="locked_door_white"&&this.name.up_empty!="locked_door_black" ) {
			this.upTemp=1;
				if(this.name.up_empty == "irSensor"){
	  			this.objUp.className = "explode";
	  			this.life-=50;
	  			plasmaGunShoot.play();
					}
				}else{
					this.upTemp = 0;
				}
			}
		

			}catch{
					this.upTemp = 0;
					this.downTemp = 0;
					this.leftTemp = 0;
					this.rightTemp = 0;
			}
		}
}

	moveRight() {
		this.name.innerHTML=this.life;
		this.name.get_coordinates(this.name.getBoundingClientRect());
		this.name.style.backgroundImage='URL("IMG/' + this.name.className + '_r.gif")';
		if (this.rightTemp==1 && this.name.down_empty!= "world" && this.name.down_empty!= "interface" && this.name.up_empty!= "world" && this.name.up_empty!= "interface" && ((this.name.temp+this.name.speed)<=1400)) {
		this.name.temp=this.name.temp+this.name.speed;
		this.name.style.left = this.name.temp + 'px';
		}
	}

	moveLeft() {
		this.name.innerHTML=this.life;
		 this.name.get_coordinates(this.name.getBoundingClientRect());
		this.name.style.backgroundImage='URL("IMG/' + this.name.className + '_l.gif")';
		if (this.leftTemp==1 && this.name.down_empty!= "world" && this.name.down_empty!= "interface" && this.name.up_empty!= "world" && this.name.up_empty!= "interface" &&((this.name.temp-this.name.speed)>=50)) {
		this.name.temp=this.name.temp-this.name.speed;
		this.name.style.left = this.name.temp + 'px';
		}
	}

	moveUp() {
		this.name.innerHTML=this.life;
		this.name.get_coordinates(this.name.getBoundingClientRect());
		this.name.style.backgroundImage='URL("IMG/' + this.name.className + '_r.gif")';
		if (this.upTemp==1 && ((this.name.vertical+this.name.speed)<=1400)) { 
		this.name.vertical=this.name.vertical+this.name.speed;
		this.name.style.bottom = this.name.vertical + 'px';
		}
	}

	moveDown() {
		this.name.innerHTML=this.life;
		this.name.get_coordinates(this.name.getBoundingClientRect());
		this.name.style.backgroundImage='URL("IMG/' + this.name.className + '_l.gif")';
		if (this.downTemp==1 && ((this.name.vertical-this.name.speed)>=50)) {
		this.name.vertical=this.name.vertical-this.name.speed;
		this.name.style.bottom = this.name.vertical + 'px';
		}
	}

	showEnemy(){
	  this.name.style.display="inline-block";
	  monsterPortalSound.play();
	}

	createThing() {
		let randomThing = Math.floor(Math.random() * (5 - 0)) + 0;
  if(randomThing == 0){
    let thing = document.createElement('div');
    thing.className = 'pistolCellsThing';
    game.appendChild(thing);
    thing.style.left = this.name.style.left;
    thing.style.bottom = this.name.style.bottom;
    }
    
   if(randomThing == 1){
    let thing = document.createElement('div');
    thing.className = 'shootgunCellsThing';
    game.appendChild(thing);
    thing.style.left = this.name.style.left;
    thing.style.bottom = this.name.style.bottom;
    }
  
  if(randomThing == 2){
    let thing = document.createElement('div');
    thing.className = 'medicKitThing';
    game.appendChild(thing);
    thing.style.left = this.name.style.left;
    thing.style.bottom = this.name.style.bottom;
    }

  if(randomThing == 3){
    let thing = document.createElement('div');
    thing.className = 'plasmagunCellsThing';
    game.appendChild(thing);
    thing.style.left = this.name.style.left;
    thing.style.bottom = this.name.style.bottom;
    }
  if(randomThing == 4){
    let thing = document.createElement('div');
    thing.className = 'armor';
    game.appendChild(thing);
    thing.style.left = this.name.style.left;
    thing.style.bottom = this.name.style.bottom;
    }
}

	insertDeadBotBody() {
	  var deadMonster = document.createElement('div');
	  deadMonster.className = "deadMonster";
	  deadMonster.style.left=this.name.style.left;
	  deadMonster.style.bottom=this.name.style.bottom; 
	  game.append(deadMonster);
	  setTimeout(function(){deadMonster.remove();},10000);
	}

	startSelf() {
		if(this.damage<=10){
				this.name.style.color = "green";
			}
			if(this.damage>10 && this.damage<15){
				this.name.style.color = "yellow";
			}
			if(this.damage>=15) {
				this.name.style.color = "red";
			}
		this.name.addEventListener("mousedown", ()=>{
			if(playerCanShoot==1){
				sensorPlayerAttack();
				this.life-=attack; 
	      playerCanShoot=0;
	      setTimeout(()=>{playerCanShoot=1;},500);
    	}
		}, false);
	  this.rand();
	  this.move();
	  return this;

	}

	rand(){
			let randInterval = setInterval( ()=> {
			this.direction =  Math.floor(Math.random() * (6 - 0)) + 0;}, this.speedAlienInterval);
			if(this.life<=0){
				this.name.killSelf();
				clearInterval(randInterval);
				}
			return this;
	}

	move(){
			let moveInterval = setInterval( ()=> {
	if(this.life<=0){
		this.name.killSelf();
		clearInterval(moveInterval);
	}
 	try{
   var p = figure.getBoundingClientRect();
   var mm = this.name.getBoundingClientRect();
     
    // отслеживание столкновений с ботом
 	if(( (p.bottom-mm.bottom)<=50 && (p.bottom-mm.bottom)>=-50 ) && ( (p.right-mm.right)<=50 && (p.right-mm.right)>=-50 ) ) {
  if(life<0){
  panel.innerHTML="life: "+ life;;
  showMassege();
  window.navigator.vibrate([100,100,30,100,100,30,100,100,30]);
  setTimeout(exit, 5000);
 
	}
	else{
  	life-=this.damage;
  	localStorage.setItem('life', life);
  	try{
  		panel.innerHTML="life: " + life + " scores: " + scores;
  	}catch{
  		panel.innerHTML="life: " + life;
  	}
  	// figure.innerHTML="<span>"+life+"</span>";
  	// figure.style.filter = "url(#yellow-outline)";
  	// setTimeout(function(){figure.style.filter = "none"},200);
  	window.navigator.vibrate(50);
  	monsterAttack.play();
		 	}
		}
    if(p.right-mm.right<200 && p.right-mm.right>0){
      this.moveRight(); 
    }  
     if(p.right-mm.right>-200 && p.right-mm.right<0){
      this.moveLeft();
    }
      if(p.bottom-mm.bottom<200 && p.bottom-mm.bottom>0){
      this.moveDown();  
    }
     if(p.bottom-mm.bottom>-200 && p.bottom-mm.bottom<0){
      this.moveUp();
    }
    else{
    		if(this.direction==0){	
		      this.moveRight();	       
		    }
		    else
		    if(this.direction==1){	    	
		      this.moveLeft();	       	      
		    }
		    else
		    if(this.direction==2){	    	
		      this.moveUp();	       	      
		    }
		    else
		    if(this.direction==3){	    	
		      this.moveDown();	       	      
		    }
		    else
		    	if(this.direction==4){
		    	// this.createSelfCopy();
		    }else{
		    	
		    }
		    return this; 
    }
	}
	catch(e){
		}
	}, this.speedAlienInterval);
}

	createSelfCopy(){
		let randomName;
		let randomInt = Math.floor(Math.random() * (4 - 0)) + 0;
		if(randomInt == 0){
			randomName = "alien";
		}
		if(randomInt == 1){
			randomName = "monsterblob";
		}
		if(randomInt == 2){
			randomName = "monstersnake";
		}
		if(randomInt == 3){
			randomName = "monsterthongle";
		}
			if(alienCounter<=alienMaximum){
				let alien = "alien" +(++alienCounter);
				console.log("created " + alien);
				console.log(this.damage);
	    	alien = new Enemy(randomName, randomName, parseInt(this.name.style.left, 10), parseInt(this.name.style.bottom, 10), 100);
				alien.startSelf();
		 }
	}

	insertDeadBody() {
         let deadMonster = document.createElement('div');
         deadMonster.className = "deadMonster";
         deadMonster.style.left=this.name.style.left;
         deadMonster.style.bottom=this.name.style.bottom; 
         game.append(deadMonster);
}


	createEnemySoul(){
	    let soul = document.createElement('div');
	    soul.className = 'soul-thing';
	    game.appendChild(soul);
	    soul.style.left = this.name.style.left;
	    soul.style.bottom = this.name.style.bottom;
	    setTimeout(function(){
	      soul.remove();
	    },500);
	}

}


var bodyClass = document.getElementsByTagName("body")[0];
bodyClass.classList.add("interface");






