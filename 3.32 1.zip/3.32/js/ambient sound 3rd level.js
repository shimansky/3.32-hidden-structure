var ambient = new Audio('SOUND/3rd level ambient.mp3');
ambient.loop = true;