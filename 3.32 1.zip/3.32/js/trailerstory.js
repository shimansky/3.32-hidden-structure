var languege = localStorage.getItem('lang');
var story = document.getElementById("story");
var skipStory = document.getElementById("skipStory");


var intro = new Audio('SOUND/intro.mp3');

var aSlideRus = "Шоссе почти пустое, и я могу ехать так быстро как может моя машина, Лииса уже заждалась наверное в пиццерии...она всегда назначала мне встречу именно там, ей было так удобно, ведь она работала в здании напротив...";
var aSlideEng = "The highway is almost empty, and I can go as fast as my car can, Liisa is probably tired of waiting in a pizzeria ... she always made an appointment for me there, it was so convenient for her, because she worked in the building opposite ...";

var bSlideRus = "Почти доехав до города машина перестала меня слушаться -  внезапно двигатель просто выключился и погасли фары, стало быстро темнеть из динамиков машины раздался сильный треск!...";
var bSlideEng = "Having almost reached the city, the car stopped obeying me - suddenly the engine just turned off and the headlights went out, it began to darken quickly from the car speakers there was a strong crack! ...";

var cSlideRus = "Я выскочил наружу, вокруг была тишина... Далеко слышались раскаты грома... Шоссе проходило через лес к зданию Orbita technology, где работала Лииса и в той стороне возникла яркая вспышка света, которая сразу погасла, оставив за собой бледно-зеленое свечение на небе... Внезапно запустился двигатель и включился свет фар!...";
var cSlideEng = "I jumped out, there was silence around ... Thunder was heard far away ... The highway passed through the forest to the Orbita technology building, where Liisa worked, and in that direction there was a bright flash of light, which immediately went out, leaving behind a pale green glow on the sky ... Suddenly the engine started and the headlights turned on! ...";

var dSlideRus = "Я выжимал из автомобиля, все что мог, в голове была только мысль - Лииса!... Что там произошло?...Машина мчалась по шоссе как сумасшедшая,стараясь срезать каждый поворот, оставляя на асфальте темные полосы я резко затормозил - дорогу перекрыли полицейские машины...Вход в здание Orbita technology был перекрыт...Вокруг было темно, в городе не было света...и улицы были пустыми...возле машин не было ни одного полицейского...только где-то вдалеке мерцала неоновая вывеска пиццерии...";
var dSlideEng = "I squeezed out of the car, everything I could, in my head there was only a thought - Liisa! ... What happened there? ...The car rushed along the highway like crazy, trying to cut off every turn, leaving dark stripes on the asphalt, I braked sharply - the road was blocked by police cars ... The entrance to the Orbita technology building was blocked ...It was dark around, there was no light in the city ... and the streets were empty ... there were no police officers near the cars ... only the neon sign of a pizzeria flickered somewhere in the distance ...";

var startRus = "<button id='startButton' onClick='startStory()'>трейлер</button>";
var startEng = "<button id='startButton' onClick='startStory()'>trailer</button>";

var skipRus = "<button id='skipButton' onClick='goToUrl()'>в игру</button>";
var skipEng = "<button id='skipButton' onClick='goToUrl()'>skip</button>";



function translateTrailerButton(){
	if(languege==1){
        story.innerHTML=startRus;
        skipStory.innerHTML=skipRus;
	}
	else{
		story.innerHTML=startEng;
		skipStory.innerHTML=skipEng;
	}
}

function translateA(){
	if(languege==1){
        story.innerHTML=aSlideRus;
	}
	else{
		story.innerHTML=aSlideEng;
	}
}

function translateB(){
	if(languege==1){
        story.innerHTML=bSlideRus;
	}
	else{
		story.innerHTML=bSlideEng;
	}
}

function translateC(){
	if(languege==1){
        story.innerHTML=cSlideRus;
	}
	else{
		story.innerHTML=cSlideEng;
	}
}

function translateD(){
	if(languege==1){
        story.innerHTML=dSlideRus;
	}
	else{
		story.innerHTML=dSlideEng;
	}
}

function goToUrl(){
	document.location.href = "room12.html";
}


function startStory(){
intro.play();
timerA = setTimeout(translateA, 0);
timerB = setTimeout(translateB, 10000);
timerC = setTimeout(translateC, 22000);
timerD = setTimeout(translateD, 32000);
timerGo = setTimeout(goToUrl, 50000);
}

translateTrailerButton();


