var ambient = new Audio('SOUND/PowerDrive.mp3');
ambient.loop = true;

function playMusic() {
	ambient.play();
}

createTab("<p >just survive as you can!!!</p> <button onclick='playMusic(), closeTab()'>ок</button>")