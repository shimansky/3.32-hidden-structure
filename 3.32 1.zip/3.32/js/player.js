


const figureLeftImg = "IMG/player_l.gif";
          preloadImage(figureLeftImg);

const figureRightImg = "IMG/player_r.gif";
          preloadImage(figureRightImg);

const figureTopImg = "IMG/player_top.gif";
          preloadImage(figureTopImg);

const figureDownImg = "IMG/player_r.gif";
          preloadImage(figureDownImg);

const figureHitImg = "IMG/player_hit.gif";
          preloadImage(figureHitImg);

const figureShootImg = "IMG/player_shoot.gif";
          preloadImage(figureShootImg);

const figureStayLeftImg = "IMG/player_l.png";
          preloadImage(figureStayLeftImg);

const figureStayRightImg = "IMG/player_r.png";
           preloadImage(figureStayRightImg);

const figureInTeleportationImg = "IMG/playerTeleportation.gif";
          preloadImage(figureInTeleportationImg);

const playerLighter = "IMG/test2.png";
          preloadImage(playerLighter);

          
         
          

var playerLeftXDistance=-7;
var playerRightXDistance=7;
var playerUpYDistance=7;
var playerDownYDistance=-7;
var left;
var bottom;
var life;
var cells = +localStorage.getItem('cells');
var sCells = +localStorage.getItem('sCells');
var plCells = +localStorage.getItem('plCells');
var wievport=document.getElementById('wievport');
var steps = new Audio('SOUND/step.mp3');
var pistolShoot = new Audio('SOUND/pistol.mp3');
var shootGunShoot = new Audio('SOUND/shootGun.mp3');
var plasmaGunShoot = new Audio('SOUND/plasmagun.mp3');
var punch = new Audio('SOUND/punch.mp3');
var setSensor = new Audio('SOUND/irSensor.mp3');
var damage = new Audio('SOUND/damage.mp3');
var playerCanShoot=1;
var granadesCount=5;

var timerUp;
var timerDown;
var timerLeft;
var timerRight;

var flagInHit=0;

var flagUp=0;
var flagDown=0;
var flagLeft=0;
var flagRight=0;

var leftInMove=0;
var rightInMove=0;
var upInMove=0;
var downInMove=0;

var pistolBullet;
var pistolBulletLeft;
var leftPistolBulletDistance=0;
var bottomPistolBulletDistance=0;
var inBulletFly=0;

var flagPistol = +localStorage.getItem('flagPistol');
var flagShootgun = +localStorage.getItem('flagShootgun');
var flagPlasmagun = +localStorage.getItem('flagPlasmagun');
var flagSelect=1;

var flagStayLeft=0;
var flagStayRight=0;


figure=document.getElementById('player');
figure.innerHTML="<img src='img/test2.png' class='playerBackRight'>";
let playerBackRight = document.getElementsByClassName("playerBackRight")[0];




 // функции управления игроком
function changePlayerImg(){
  
       if(upInMove==1){
      figure.style.backgroundImage='URL('+ figureTopImg+')'}
      else
       if(downInMove==1){
      figure.style.backgroundImage='URL('+ figureDownImg+')'}
      else
        if(leftInMove==1){
      figure.style.backgroundImage='URL('+ figureLeftImg+')'}
      else
        if(rightInMove==1){
      figure.style.backgroundImage='URL('+ figureRightImg+')'}
       else
        {
      figure.style.backgroundImage='URL('+ figureStayLeftImg+')'}
}

function changePlayerImgThenButtonUp(){
  
       if(flagUp==1){
      figure.style.backgroundImage='URL('+ figureTopImg+')'}
      else
       if(flagDown==1){
      figure.style.backgroundImage='URL('+ figureDownImg+')'}
      else
        if(flagLeft==1){
      figure.style.backgroundImage='URL('+ figureStayLeftImg+')'}
      else
        if(flagRight==1){
      figure.style.backgroundImage='URL('+ figureStayRightImg+')'}
       else
        {
            if(flagStayLeft==1){figure.style.backgroundImage='URL('+ figureStayLeftImg+')'}
             else
               if (flagStayRight==1){figure.style.backgroundImage='URL('+ figureStayRightImg+')'}
        }
}


function setImgPlayerTeleportation(){
  figure.style.backgroundImage='URL('+ figureInTeleportationImg +')';
  clearInterval(timerLeft);
  clearInterval(timerRight);
  clearInterval(timerUp);
  clearInterval(timerDown);
  flagLeft=0;
  leftInMove=0;
  flagRight=0;
  rightInMove=0;
  flagDown=0;
  downInMove=0;
  flagUp=0;
  upInMove=0;
}

function changePlayerImgInTeleportation(){
  figure.style.backgroundImage='URL('+ figureStayLeftImg+')';
  inTeleportation=0;
}


 figure.moveLeft=function(distance){
   var p = figure.getBoundingClientRect();
   get_coordinates(p);
    if (leftTemp==1) {
    left=left+distance;
    this.style.left = left +'px';
    setCurrentView();
    // steps.play();
    }
}

 figure.moveRight=function(distance){
   var p = figure.getBoundingClientRect();
   get_coordinates(p);
    if (rightTemp==1) {
    left=left+distance;
    this.style.left = left +'px';
    setCurrentView();
    // steps.play();
    }
}

 figure.moveUp=function(distance){
   var p = figure.getBoundingClientRect();
   get_coordinates(p);
    if (upTemp==1) {
    bottom=bottom+distance;
    this.style.bottom = bottom +'px';
    setCurrentView();
    // steps.play();
    }
}

 figure.moveDown=function(distance){
   var p = figure.getBoundingClientRect();
   get_coordinates(p);
    if (downTemp==1) {
    bottom=bottom+distance;
    this.style.bottom = bottom +'px';
    setCurrentView();
    // steps.play();
    }
}

figure.hit=function(){
    if(flagPistol==1 && cells>0 && flagSelect==2){
          playerHitByPistol();
         }
    else   
        
    if(flagShootgun==1 && sCells>0 && flagSelect==3){
          playerHitByShootgun();
         }
     else   
        
    if(flagPlasmagun==1 && plCells>0 && flagSelect==4){
          playerHitByPlasmagun();
         }   
    else{
          playerHitByArms();     
         }
      
   
}

function playerHitByArms(){
   if(inBulletFly==0){
            inBulletFly=1;
      attack=5;
      figure.style.backgroundImage='URL('+ figureHitImg+')';
      punch.play();
      setTimeout(changePlayerImg,300);
      console.log("attack: "+attack);
      setTimeout(readyToShoot,500);
      try{
        requestingForDamage();
      }catch{

      }
      
    }
}

function playerHitByPistol(){
     if(cells>0){
         if(inBulletFly==0){
            inBulletFly=1;
              attack=30;
              cells-=1;
              iconPistol.innerHTML=cells;
              figure.style.backgroundImage='URL('+ figureShootImg+')';
               try{
                pistolShoot.pause();
                pistolShoot.currentTime = 0;
                }catch{
                  console.log(error);
                }
              pistolShoot.play();
              setTimeout(changePlayerImg,500);
              console.log("attack: "+attack);
              console.log("cells: "+cells);
              setTimeout(readyToShoot,500);
              try{
                requestingForDamage();
              }catch{

              }
              
            }
        }
    
}

function playerHitByShootgun(){
      if(sCells>0){
          if(inBulletFly==0){
            inBulletFly=1;
             attack=51;
             sCells-=1;
             iconShootgun.innerHTML=sCells;
             figure.style.backgroundImage='URL('+ figureShootImg+')';
             try{
                shootGunShoot.pause();
                shootGunShoot.currentTime = 0;
                }catch{
                  console.log(error);
                }
             shootGunShoot.play();
             setTimeout(changePlayerImg,500);
             console.log("attack: "+attack);
             console.log("cells: "+sCells);
             setTimeout(readyToShoot,500);
             try{
              requestingForDamage();
             }catch{

             }
             
             }
       }
}

function playerHitByPlasmagun(){
      if(plCells>0){
          if(inBulletFly==0){
            inBulletFly=1;
             attack=101;
             plCells-=1;
             iconPlasmagun.innerHTML=plCells;
             figure.style.backgroundImage='URL('+ figureShootImg+')';
             try{
                plasmaGunShoot.pause();
                plasmaGunShoot.currentTime = 0;
                }catch{
                  console.log(error);
                }
             plasmaGunShoot.play();
             setTimeout(changePlayerImg,500);
             console.log("attack: "+attack);
             console.log("cells: "+plCells);
             setTimeout(readyToShoot,500);
             try{
              requestingForDamage();
             }catch{

             }
             
             }
       }
}

function playerHitByGranade(){
      
          
            
             attack=80; 
             var dissappear = document.createElement('div');
             dissappear.className = "irSensor";
             dissappear.style.left=player.style.left;
             dissappear.style.bottom=player.style.bottom; 
             game.append(dissappear);
             setSensor.play();
             console.log("attack: "+attack);
             console.log("granade!");
             // setTimeout(function(){dissappear.remove()},1000);
             // setTimeout(readyToShoot,1100);
             // requestingForDamage();
             }
       


function readyToShoot(){
  inBulletFly=0;
}

function playerMoveLeft(){
  figure.moveLeft(playerLeftXDistance);
  // figure.innerHTML="<img src='img/test2.png' class='playerBackLeft lighterAnimation'>";
  playerBackRight.style.transform = "rotate(180deg)";
}

function playerMoveRight(){
  figure.moveRight(playerRightXDistance);
  // figure.innerHTML="<img src='img/test2.png' class='playerBackRight lighterAnimation'>";
  playerBackRight.style.transform = "rotate(0deg)";
}

function playerMoveUp(){
  figure.moveUp(playerUpYDistance);
  // figure.innerHTML="<img src='img/test3.png' class='playerBackUp lighterAnimation'>";
  playerBackRight.style.transform = "rotate(270deg)";
}

function playerMoveDown(){
  figure.moveDown(playerDownYDistance);
  // figure.innerHTML="<img src='img/test3.png' class='playerBackDown lighterAnimation'>";
  playerBackRight.style.transform = "rotate(90deg)";
}

function playerHit(){
  figure.hit();
}









// обаботчики нажатий на клавиши
window.onkeydown = function(){
    if(inTeleportation==0){

        // shift
        if(event.keyCode==16){
      playerLeftXDistance=-10;
      playerRightXDistance=10;
      playerUpYDistance=10;
      playerDownYDistance=-10;
    }

  // left
        if(event.keyCode==65){
          figure.style.backgroundImage='URL('+ figureLeftImg+')';
          leftInMove=1;
          if(flagLeft==0){
     flagLeft=1;
     flagStayRight=0;
     flagRight=0;
     rightInMove=0;
     flagDown=0;
     downInMove=0;
     flagUp=0;
     upInMove=0;
    try{
      clearInterval(timerRight);
      clearInterval(timerUp);
      clearInterval(timerDown);
    }
    catch{}
     timerLeft = setInterval(playerMoveLeft,50);
      }
}
  // right
    else if(event.keyCode==68){
     figure.style.backgroundImage='URL('+ figureRightImg+')';
      rightInMove=1;
      if(flagRight==0){
      flagRight=1;
      flagStayLeft=0;
      flagLeft=0;
      leftInMove=0;
      flagDown=0;
      downInMove=0;
      flagUp=0;
      upInMove=0;
    try{
      clearInterval(timerLeft);
      clearInterval(timerUp);
      clearInterval(timerDown);
    }
    catch{}
      timerRight = setInterval(playerMoveRight,50);
    }
}

   // up
    else if(event.keyCode==87){
    figure.style.backgroundImage='URL('+ figureTopImg+')';
      upInMove=1;
      if(flagUp==0){
      flagUp=1;
      flagRight=0;
      rightInMove=0;
      flagDown=0;
      downInMove=0;
      flagLeft=0;
      leftInMove=0;
          try{
      clearInterval(timerDown);
      clearInterval(timerLeft);
      clearInterval(timerRight);
    }
    catch{}

      timerUp = setInterval(playerMoveUp,50);
    }
   
}

   // down
    else if(event.keyCode==83){
    figure.style.backgroundImage='URL('+ figureDownImg+')';
     downInMove=1;
     if(flagDown==0){
      flagDown=1;
      flagRight=0;
      rightInMove=0;
      flagLeft=0;
      leftInMove=0;
      flagUp=0;
      upInMove=0;
          try{
      clearInterval(timerUp);
      clearInterval(timerLeft);
      clearInterval(timerRight);
    }
    catch{}

      timerDown = setInterval(playerMoveDown,50);
    }
}

     // hit
    else if(event.keyCode==190){
     if (flagInHit==0) {
          flagInHit=1
          playerHit();
            }
    }

     // setGranade

    else if(event.keyCode==69){ 
    
     if(granadesCount>0){
      playerHitByGranade();
      granadesCount--;
        }
    }
    
  // select weapon

  // 1 - arms
    else if(event.keyCode==49){
      selectArmAttack();
    }
  // 2 - pistol
    else if(event.keyCode==50){
      selectPistolAttack();
    }

  // 3 - shootgun
    else if(event.keyCode==51){
     selectShootgunAttack();
    }

  // 4 - plasmagun
    else if(event.keyCode==52){
     selectPlasmagunAttack();
    }
   }
}

     // обаботчики нажатий на клавиши
window.onkeyup = function(){
    if(inTeleportation==0){ 

// shift
      if(event.keyCode==16){
      playerLeftXDistance=-7;
      playerRightXDistance=7;
      playerUpYDistance=7;
      playerDownYDistance=-7;   
    }

  // left
        if(event.keyCode==65){
          flagLeft=0;
          leftInMove=0;
          flagStayLeft=1;
          clearInterval(timerLeft);
          changePlayerImgThenButtonUp();
       
}
  // right
    else if(event.keyCode==68){
          flagRight=0;
          rightInMove=0;
          flagStayRight=1;
          clearInterval(timerRight);
          changePlayerImgThenButtonUp();
}
   // down
    else if(event.keyCode==83){
          flagDown=0;
          downInMove=0;
          clearInterval(timerDown);
          changePlayerImgThenButtonUp();
}
   // up
    else if(event.keyCode==87){
          flagUp=0;
          upInMove=0;
          clearInterval(timerUp);
          changePlayerImgThenButtonUp();
     
}
     // hit
    else if(event.keyCode==190){
      flagInHit=0;
    }
  }
}



function selectArmAttack(){
      flagSelect=1;
      console.log("weapon: arms");
      iconPistol.style.border="none";
      iconShootgun.style.border="none";
      iconPlasmagun.style.border="none";
}

function selectPistolAttack(){
      flagSelect=2;
      console.log("weapon: pistol");
      iconPistol.style.border="1px solid red";
      iconShootgun.style.border="none";
      iconPlasmagun.style.border="none";
}

function selectShootgunAttack(){
      flagSelect=3;
      console.log("weapon: shootgun");
      iconPistol.style.border="none";
      iconPlasmagun.style.border="none";
      iconShootgun.style.border="1px solid red";
}

function selectPlasmagunAttack(){
      flagSelect=4;
      console.log("weapon: plasmagun");
      iconPistol.style.border="none";
      iconShootgun.style.border="none";
      iconPlasmagun.style.border="1px solid red";
}


function sensorPlayerAttack(){
 
     if (flagInHit==0) {
          flagInHit=1
          playerHit();
          
          
            }
       flagInHit=0;
            
}


function requestingForDamage(){
     
     

     // var p = figure.getBoundingClientRect();
     // var m = enemy.getBoundingClientRect();
     // var m2 = enemy2.getBoundingClientRect();

     // // hit by arms
          
     //      if (( (p.bottom-m.bottom)<=50 && (p.bottom-m.bottom)>=-50 ) && ( (p.right-m.right)<=50 && (p.right-m.right)>=-50 ) ) {
     //              botLife-=attack;
     //              enemy.style.filter = "url(#yellow-outline)";
     //              setTimeout(function(){enemy.style.filter = "none"},200);
     //                }
     //      if (( (p.bottom-m2.bottom)<=50 && (p.bottom-m2.bottom)>=-50 ) && ( (p.right-m2.right)<=50 && (p.right-m2.right)>=-50 ) ) {
     //              botLife2-=attack;
     //              enemy2.style.filter = "url(#yellow-outline)";
     //              setTimeout(function(){enemy2.style.filter = "none"},200);
     //                }

        


     //       if(cells>0 || sCells>0 || plCells>0){

     //        try{

     //          patron = document.getElementsByClassName('patron')[0];
     //          patron2 = document.getElementsByClassName('patron2')[0];
              
              
     //          var pat = patron.getBoundingClientRect();
     //          var pat2 = patron.getBoundingClientRect();
               

     //          // hit by weapons
     
     //      if (( (pat.bottom-m.bottom)<=50 && (pat.bottom-m.bottom)>=-50 ) && ( (pat.right-m.right)<=50 && (pat.right-m.right)>=-50 ) ) {
     //              botLife-=attack;
     //              enemy.style.filter = "url(#yellow-outline)";
     //              setTimeout(function(){enemy.style.filter = "none"},200);
     //                }
     //      if (( (pat2.bottom-m2.bottom)<=50 && (pat2.bottom-m2.bottom)>=-50 ) && ( (pat2.right-m2.right)<=50 && (pat2.right-m2.right)>=-50 ) ) {
     //              botLife2-=attack;
     //              enemy2.style.filter = "url(#yellow-outline)";
     //              setTimeout(function(){enemy2.style.filter = "none"},200);
     //                }

     //                }catch{
     //            console.log('bad shoot!');
     //          }
                    
     //       }




     //                try{
     //                   var bossm2 = bossenemy2.getBoundingClientRect();
     //                    if (( (p.bottom-bossm2.bottom)<=100 && (p.bottom-bossm2.bottom)>=-100 ) && ( (p.right-bossm2.right)<=100 && (p.right-bossm2.right)>=-100 ) ) {
     //                      BossbotLife2-=attack;
     //                      bossenemy2.style.filter = "url(#yellow-outline)";
     //                      setTimeout(function(){bossenemy2.style.filter = "none"},200);
                          
     //                      }
     //                }
     //                catch{}
          


            }
      


function preloadImage(url) {
     const img = new Image(); 
     img.src = url; } 






// Joystik

function joyHit(){
  if(inTeleportation==0){
    if (flagInHit==0) {
          flagInHit=1
          playerHit();
       }
      }
     }

     function joySetGrenade() {
         if(granadesCount>0){
             playerHitByGranade();
             granadesCount--;
         }
     }

function joyUp(){
   if(inTeleportation==0){
    figure.style.backgroundImage='URL('+ figureTopImg+')';
      upInMove=1;
      if(flagUp==0){
      flagUp=1;

      flagRight=0;
      rightInMove=0;
      flagDown=0;
      downInMove=0;
      flagLeft=0;
      leftInMove=0;

          try{
      clearInterval(timerDown);
      clearInterval(timerLeft);
      clearInterval(timerRight);
    }
    catch{}

      timerUp = setInterval(playerMoveUp,50);
       }
   }
}

function joyDown(){
   if(inTeleportation==0){
    figure.style.backgroundImage='URL('+ figureDownImg+')';
     downInMove=1;
     if(flagDown==0){
      flagDown=1;

      flagRight=0;
      rightInMove=0;
      flagLeft=0;
      leftInMove=0;
      flagUp=0;
      upInMove=0;

  
          try{
      clearInterval(timerUp);
      clearInterval(timerLeft);
      clearInterval(timerRight);
    }
    catch{}

      timerDown = setInterval(playerMoveDown,50);
      }  

   }
}

function joyLeft(){
   if(inTeleportation==0){
          figure.style.backgroundImage='URL('+ figureLeftImg+')';
          leftInMove=1;
          if(flagLeft==0){
     flagLeft=1;
     flagStayRight=0;
     flagRight=0;
     rightInMove=0;
     flagDown=0;
     downInMove=0;
     flagUp=0;
     upInMove=0;
    try{
      clearInterval(timerRight);
      clearInterval(timerUp);
      clearInterval(timerDown);
    }
    catch{}
     timerLeft = setInterval(playerMoveLeft,50);

     }
   }
}

function joyRight(){
   if(inTeleportation==0){
     figure.style.backgroundImage='URL('+ figureRightImg+')';
      rightInMove=1;
      if(flagRight==0){
      flagRight=1;
      flagStayLeft=0;
      flagLeft=0;
      leftInMove=0;
      flagDown=0;
      downInMove=0;
      flagUp=0;
      upInMove=0;

    try{
      clearInterval(timerLeft);
      clearInterval(timerUp);
      clearInterval(timerDown);
    }
    catch{}
      timerRight = setInterval(playerMoveRight,50);
     }
    }
   }



function joyHitEnd(){
  if(inTeleportation==0){
     flagInHit=0;
  }
}

function joyLeftEnd(){
 if(inTeleportation==0){
          flagLeft=0;
          leftInMove=0;
          flagStayLeft=1;
          clearInterval(timerLeft);
        changePlayerImgThenButtonUp();
}       
}

function joyRightEnd(){
   if(inTeleportation==0){
          flagRight=0;
          rightInMove=0;
          flagStayRight=1;
          clearInterval(timerRight);
        changePlayerImgThenButtonUp();
}
}

function joyDownEnd(){
   if(inTeleportation==0){
          flagDown=0;
          downInMove=0;
          clearInterval(timerDown);
    

     changePlayerImgThenButtonUp();
}
}
 
function joyUpEnd(){
 if(inTeleportation==0){
          flagUp=0;
          upInMove=0;
          clearInterval(timerUp);
    

     changePlayerImgThenButtonUp();
     
}
}

