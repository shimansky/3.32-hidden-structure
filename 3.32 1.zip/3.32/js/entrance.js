var entranceIsOpened = 0;
var entrance = document.getElementById('entrance');
var tool = document.getElementById('tool');
var bedroomEntranceText = "Кажется через эту решетку можно попасть в соседнее здание, единственный способ - найти инструмент, чтобы ее снять";
var findToolText = "С помощью этой штуки можно демонтировать что угодно, она мне пригодиться.";
var useToolText = "Отлично, эта штука помогла снять решетку!";

function openEntrance() {
	if(entranceIsOpened) {
		entrance.style.left = "1031px";
		entrance.style.bottom = "1407px";
		entrance.style.transform = "rotate(32deg)";
		createTab(useToolText);
	}else{
		createTab(bedroomEntranceText);
	}
}

function findingTool(){
var et = tool.getBoundingClientRect();
var p = figure.getBoundingClientRect();
if (( (p.bottom-et.bottom)<=25 && (p.bottom-et.bottom)>=-25 ) && ( (p.right-et.right)<=25 && (p.right-et.right)>=-25 ) ) {
  entranceIsOpened = 1;
  createTab(findToolText);
  tool.style.display = "none";
  clearInterval(find);
	}
}

var find = setInterval(findingTool,200);


