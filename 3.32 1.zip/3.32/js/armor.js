// armor

function CreateNewArmor(left, bottom) {
         var item = document.createElement('div');
         item.className = "armor";
         item.points=50;
         item.style.left=left+'px';
         item.style.bottom=bottom+'px';
         game.append(item);
         console.log('armor added');
}