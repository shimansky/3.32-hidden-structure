var ambient = new Audio('SOUND/1st level ambient.mp3');
ambient.loop = true;