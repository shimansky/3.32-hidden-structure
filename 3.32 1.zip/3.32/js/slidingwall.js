var slidingWall = document.getElementById('slidingWall');
var beginingPosition=+slidingWall.style.bottom.toString().slice(0, -2);


function slideDown(){
	slidingWall.style.transition= "all 4s linear";
	var position=+slidingWall.style.bottom.toString().slice(0, -2);
	 slidingWall.style.bottom = position-200+"px";
}

function slideUp(){
	slidingWall.style.transition= "all 1s linear";
	var position=+slidingWall.style.bottom.toString().slice(0, -2);
	 slidingWall.style.bottom = position+50+"px";
}

function resetPosition(){
	slidingWall.style.transition= "none";
	 slidingWall.style.bottom = beginingPosition+"px";
}



function animatedWall(){
	setTimeout(slideDown, 100);
	setTimeout(resetPosition, 4100);
	
}

setInterval(animatedWall, 4100);