var menuItem = new Audio('SOUND/menuItem.mp3');

function menuItemPlay(){
	menuItem.pause();
	menuItem.currentTime = 0;
	menuItem.play();
}