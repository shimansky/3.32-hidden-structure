let cloud =  document.createElement('div');
	  cloud.className = "cloud";
	  cloud.style.left="0";
	  cloud.style.bottom="0"; 
	  game.append(cloud);
	  