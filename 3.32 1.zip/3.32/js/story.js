  var textRu='<div id="robertIMG"></div><br>Я выжимал из автомобиля, все что мог, в голове была только мысль - Лииса!... Что там произошло?...Машина мчалась по шоссе как сумасшедшая,стараясь срезать каждый поворот, оставляя на асфальте темные полосы я резко затормозил - дорогу перекрыли полицейские машины...Вход в здание Orbita technology был перекрыт...Вокруг было темно, в городе не было света...и улицы были пустыми...возле машин не было ни одного полицейского...только где-то вдалеке мерцала неоновая вывеска пиццерии...';
  
  var textEng='<div id="robertIMG"></div><br>I squeezed out of the car, everything I could, there was only a thought in my head - Liisa! ... What happened there? ...The car rushed along the highway like crazy, trying to cut off every turn, leaving dark stripes on the asphalt, I braked sharply - the road was blocked by police cars ... The entrance to the Orbita technology building was blocked ...It was dark around, there was no light in the city ... and the streets were empty ... there were no police officers near the cars ... only a neon sign of a pizzeria flickered somewhere in the distance ...';

  function showStory(Ru,Eng){
  flagInHit=0;
  
  tab = document.createElement('div');
  tab.className = "tab";
  if (language==1){
    tab.innerHTML=  Ru + '<br><button onclick="closeTab(), ambient.play()">ok</button>' 
  }else
     {tab.innerHTML= Eng + '<br><button onclick="closeTab(), ambient.play()">ok</button>' };
  tab.style.left=window.innerWidth/2-90+"px";
  // tab.style.top=window.innerHeight/3+"px";
  inTeleportation=1;
  wievport.append(tab);
  tab.onclick = function(){flagInHit=1};
  flagLeft=0;
  leftInMove=0;
  clearInterval(timerLeft);
  flagRight=0;
  rightInMove=0;
  clearInterval(timerRight);
  flagDown=0;
  downInMove=0;
  clearInterval(timerDown);
  flagUp=0;
  upInMove=0;
  clearInterval(timerUp);
  changePlayerImgThenButtonUp();
  ambient.volume = 0.3;
  // clearInterval(timerId);
  // clearInterval(timerId2);
  }



setTimeout(function(){showStory(textRu,textEng)},100);
  // showStory(textRu,textEng);

