var tempMap = +prompt("select map from 0 to 99");
var row = 30;
var col = 30;
var newMap =["["];
var Enemy;
var isDrawing = 0;

// загрузка файла карты уровня
function loadMap(){
var script=document.createElement("script");
script.src='MAPS/room'+ tempMap + '.js';
document.getElementsByTagName('head')[0].appendChild(script);
}

// отрисовка карты уровня из подгруженого файла
function render () {
    for (var r = 0; r < row; r++) {
        for (var c = 0; c < col; c++) {
            var tile = map[ r ][ c ];
            let div = document.createElement('div');
            div.className = tile;
            div.innerHTML = ("&nbsp");
            game.append(div);
        }

    }
}


// логика работы редактора карт
function getIdOfDiv(){
  try{
document.querySelector('#editor').addEventListener('click', function(e){ 
  tempClassName= e.target.className; 
  console.log(tempClassName);
  return tempClassName;
});
 }
 catch{
  console.log("editor not loaded");
 }
}

function setIDOfDiv(){
  if(true){
  try{
document.querySelector('#game').addEventListener('mousedown', e => {
  isDrawing = 1;
});
document.querySelector('#game').addEventListener('mouseup', e => {
  isDrawing = 0;
});

  document.querySelector('#game').onmouseover = function(event) {
    if (isDrawing == 1) {
  let target = event.target;
  target.className = tempClassName;
  console.log(tempClassName);
  }
};
// });
 }
 catch{
  console.log("target not loaded");
 }
 }
}


// вывод карты уровня в виде массива для сохранения
function createMap(){
  var mapArr=game.getElementsByTagName('*');
    var l = 0;
     for(i=0;i<=899;i++){
        
          if(l%30==0){
            newMap.push("],<br>["+'"'+mapArr[i].className+'"');
          }
          else{
             newMap.push('"'+mapArr[i].className+'"');
             console.log(mapArr[i].className);
          }
          l++;
        } 
        newMap.push("]");
        stringMap = String(newMap);
        console.log(stringMap);
        message = document.createElement('div');
        message.id = "message";
        message.style.display="block";
        message.style.fontSize="9pt";
        game.append(message);
        message.innerHTML=stringMap + "<br><button onclick=(message.remove())>close map</button>";
        newMap =["["];   
}

loadMap();

window.onload = function(){
render();
getIdOfDiv();
setIDOfDiv();
}

