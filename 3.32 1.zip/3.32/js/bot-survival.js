var botLeftXDistance=-10;
var botRightXDistance=10;
var botUpYDistance=10;
var botDownYDistance=-10;
var temp;
var vertical;
var rand;
var botLife=50;
var enemyKillCounter = 100;
var botScores = 50;
enemy=document.getElementById('monster');

enemy.addEventListener("mousedown", ()=>{
      if(playerCanShoot==1){
        botLife=botLife-attack;
        sensorPlayerAttack();
        }
});

enemy.onclick=shootToEnemy;

// var m = enemy.getBoundingClientRect();

var monsterDied = new Audio('SOUND/monsterDied.mp3');
var monsterPortalSound = new Audio('SOUND/monsterPortal.mp3');
var monsterInAttack = new Audio('SOUND/monsterInAttack.mp3');
var monsterInAttack2 = new Audio('SOUND/monsterInAttack2.mp3');

function bot_get_coordinates(unit){
  var m = enemy.getBoundingClientRect();

  // определение имени класса элемента "слева" от юнита
left_empty = document.elementFromPoint((unit.right-55),(unit.bottom-5)).className;
objLeft = document.elementFromPoint((unit.right-55),(unit.bottom-5));
if ( left_empty!="world" && left_empty!="we" && left_empty!="person" && left_empty!="w" && left_empty!="wc"&& left_empty!="ws" && left_empty!="wp" &&left_empty!="locked_door_white"&&left_empty!="locked_door_black" ) {
leftTemp=1;
// console.log(left_empty);
if(left_empty=="irSensor"){
  objLeft.className = "deadMonster";
  enemy.style.filter = "url(#yellow-outline)";
  setTimeout(function(){enemy.style.filter = "none"},200);
  botLife-=50;
  plasmaGunShoot.play();
}
}
else{
  leftTemp=0;  
}


// определение имени класса элемента "справа" от юнита
right_empty  = document.elementFromPoint((unit.right+5),(unit.bottom-5)).className;
objRight = document.elementFromPoint((unit.right+5),(unit.bottom-5));
if ( right_empty!="world" && right_empty!="we" && right_empty!="person" && right_empty!="w" && right_empty!="wc"&& right_empty!="ws" && right_empty!="wp" &&right_empty!="locked_door_white"&&right_empty!="locked_door_black" ) {
 rightTemp=1;
// console.log(rightTemp);
 if(right_empty=="irSensor"){
  objRight.className = "deadMonster";
  enemy.style.filter = "url(#yellow-outline)";
  setTimeout(function(){enemy.style.filter = "none"},200);
  botLife-=50;
  plasmaGunShoot.play();
}
}
else{
  rightTemp=0; 
}


// определение имени класса элемента "снизу" от юнита
down_empty = document.elementFromPoint((unit.right-25),(unit.bottom+5)).className;
objDown = document.elementFromPoint((unit.right-25),(unit.bottom+5));
if ( down_empty!="world" && down_empty!="we" && down_empty!="person" && down_empty!="w" && down_empty!="wc"&& down_empty!="ws" && down_empty!="wp" &&down_empty!="locked_door_white"&&down_empty!="locked_door_black" ) {
downTemp=1;
// console.log(downTemp);
if(down_empty=="irSensor"){
  objDown.className = "deadMonster";
  enemy.style.filter = "url(#yellow-outline)";
  setTimeout(function(){enemy.style.filter = "none"},200);
  botLife-=50;
  plasmaGunShoot.play();
}
}
else{
  downTemp=0; 
}


// определение имени класса элемента "сверху" от юнита
up_empty = document.elementFromPoint((unit.right-25),(unit.bottom-55)).className;
objUp = document.elementFromPoint((unit.right-25),(unit.bottom-55));
if ( up_empty!="world" && up_empty!="we" && up_empty!="person" && up_empty!="w" && up_empty!="wc"&& up_empty!="ws" && up_empty!="wp" &&up_empty!="locked_door_white"&&up_empty!="locked_door_black" ) {
upTemp=1;
// console.log(upTemp);
if(up_empty=="irSensor"){
  objUp.className = "deadMonster";
  enemy.style.filter = "url(#yellow-outline)";
  setTimeout(function(){enemy.style.filter = "none"},200);
  botLife-=50;
  plasmaGunShoot.play();
}
}
else{
  upTemp=0;
}



}

// блок функций анимации бота
enemy.moveRight=function(distance) {
    this.innerHTML=botLife;
  var m = enemy.getBoundingClientRect();
  bot_get_coordinates(m);
  this.style.backgroundImage='URL("IMG/monster_r.gif")';
if (rightTemp==1) {
  temp=temp+distance;
  this.style.left = temp + 'px';

    }
}
enemy.moveLeft=function(distance) {
    this.innerHTML=botLife;
  var m = enemy.getBoundingClientRect();
  bot_get_coordinates(m);
  this.style.backgroundImage='URL("IMG/monster_l.gif")';
if (leftTemp==1) {
  temp=temp+distance;
  this.style.left = temp + 'px';

    }
}
enemy.moveUp=function(distance) {
    this.innerHTML=botLife;
  var m = enemy.getBoundingClientRect();
  bot_get_coordinates(m);
  this.style.backgroundImage='URL("IMG/monster_r.gif")';
if (upTemp==1) { 
  vertical=vertical+distance;
  this.style.bottom = vertical + 'px';
    }
}
enemy.moveDown=function(distance) {
    this.innerHTML=botLife;
  var m = enemy.getBoundingClientRect();
  bot_get_coordinates(m);
  this.style.backgroundImage='URL("IMG/monster_l.gif")';
if (downTemp==1) {
  vertical=vertical+distance;
  this.style.bottom = vertical + 'px';
    }
}


function showEnemy(){
  enemy.style.display="inline-block";
  monsterPortalSound.play();
}

function insertDeadBotBody() {
         var deadMonster = document.createElement('div');
         deadMonster.className = "deadMonster";
         deadMonster.style.left=enemy.style.left;
         deadMonster.style.bottom=enemy.style.bottom; 
         game.append(deadMonster);
         setTimeout(function(){deadMonster.remove();},10000);
}



// ИИ для бота
function botMove(){
  if(botLife<=0){
    monsterDied.play();
       if(toggle==0){ 
         // вставка тела мертвого монстра
         insertDeadBotBody();
         
         clearInterval(timerId);
         enemy.style.display="none";
       }
 else{
    // вставка тела мертвого монстра
    insertDeadBotBody();

// вставка очков
    scores+=botScores;
    panel.innerHTML="life: " + life + " scores: " + scores;

    // вставка выпавших предметов
    var randomThing = Math.floor(Math.random() * (4 - 0));
    createThing (randomThing);

    // вставка soul и анимация
    createEnemySoul();

    enemy.style.display="none";
    enemyKillCounter-=1;
    console.log("enemyKillCounter " + enemyKillCounter);

           if (enemyKillCounter>=0) {
               setTimeout(showEnemy,  (rand2=Math.floor(Math.random() * (6 - 0)) + 0)*1000);
               botLife = rand=Math.floor(Math.random() * (200 - 0)) + 0;
               botScores = botLife;
               monsterPortal.style.left=enemy.style.left;
               monsterPortal.style.bottom=enemy.style.bottom;
               portaltemp=+monsterPortal.style.left.toString().slice(0, -2);
               portalvertical=+monsterPortal.style.bottom.toString().slice(0, -2);
               temp = portaltemp;
               vertical = portalvertical;
               enemy.style.left = temp + 'px';
               enemy.style.bottom = vertical + 'px';
           }
           else{
               insertDeadBotBody();
               clearInterval(timerId);
               enemy.style.display="none";
           }
    
      }
  }
	try{
   var p = figure.getBoundingClientRect();
   var m = enemy.getBoundingClientRect();
     
    // отслеживание столкновений с ботом
 if(( (p.bottom-m.bottom)<=50 && (p.bottom-m.bottom)>=-50 ) && ( (p.right-m.right)<=50 && (p.right-m.right)>=-50 ) ) {
  if(life<0){
  panel.innerHTML="life: " + life + " scores: " + scores;
  showMassege();
  window.navigator.vibrate([100,100,30,100,100,30,100,100,30]);
  setTimeout(exit, 5000);
 
}
else{
  life-=1;
  localStorage.setItem('life', life);
  panel.innerHTML="life: " + life + " scores: " + scores;
  // figure.innerHTML="<span>"+life+"</span>";
  // figure.style.filter = "url(#yellow-outline)";
  // setTimeout(function(){figure.style.filter = "none"},200);
  window.navigator.vibrate(50);
  monsterAttack.play();

 }
}



    if(p.right-m.right<200 && p.right-m.right>0){
      enemy.moveRight(botRightXDistance);
      
    }
    
     if(p.right-m.right>-200 && p.right-m.right<0){
      enemy.moveLeft(botLeftXDistance);
      
    }
    
      if(p.bottom-m.bottom<200 && p.bottom-m.bottom>0){
      enemy.moveDown(botDownYDistance);
      
    }
    
     if(p.bottom-m.bottom>-200 && p.bottom-m.bottom<0){
      enemy.moveUp(botUpYDistance);
      
    }

    else{

    
    
    if(rand==0){
      enemy.moveRight(botRightXDistance);
 
      
    }
    else
    if(rand==1){
      enemy.moveLeft(botLeftXDistance);
      
      
    }
    else
    if(rand==2){
      enemy.moveUp(botUpYDistance);
      
      
    }
    else
    if(rand==3){
      enemy.moveDown(botDownYDistance);
      
      
    }
    else
    if(rand==4){
      monsterInAttack.play();
      
      
    }
     else
    if(rand==5){
      monsterInAttack2.play();
      
      
    }
    
}
}
catch(e){
	
}

}

function createThing (randomThing){
  if(randomThing == 1){
    let thing = document.createElement('div');
    thing.className = 'pistolCellsThing';
    game.appendChild(thing);
    thing.style.left = enemy.style.left;
    thing.style.bottom = enemy.style.bottom;
    }
    
   if(randomThing == 2){
    let thing = document.createElement('div');
    thing.className = 'shootgunCellsThing';
    game.appendChild(thing);
    thing.style.left = enemy.style.left;
    thing.style.bottom = enemy.style.bottom;
    }
  
  if(randomThing == 3){
    let thing = document.createElement('div');
    thing.className = 'medicKitThing';
    game.appendChild(thing);
    thing.style.left = enemy.style.left;
    thing.style.bottom = enemy.style.bottom;
    }

}

function createEnemySoul(){
    let soul = document.createElement('div');
    soul.className = 'soul-thing';
    game.appendChild(soul);
    soul.style.left = enemy.style.left;
    soul.style.bottom = enemy.style.bottom;
    setTimeout(function(){
      soul.remove();
    },500);
    }

function shootToEnemy(){

  if(cells>0 || sCells>0 || plCells>0){
    if(inTeleportation==0){
    if (flagInHit==0) {
          flagInHit=1
          playerHit();
       }
      }

    let patron = document.createElement('div');
    patron.className = 'patron';
    game.appendChild(patron);
    patron.style.left = figure.style.left;
    patron.style.bottom = figure.style.bottom;
    setTimeout(function(){
      patron.style.left = enemy.style.left;
      patron.style.bottom = enemy.style.bottom;
    },100);
    setTimeout(function(){
      patron.remove();
    },500);
        console.log(cells, sCells, plCells);
      }

    }

setInterval(function(){rand=Math.floor(Math.random() * (6 - 0)) + 0},2000);