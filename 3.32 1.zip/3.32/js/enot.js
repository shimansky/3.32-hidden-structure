var flatBlackPlane = document.getElementById("flatBlackPlane");
var enot = document.getElementById("enot");
var startPhrase = document.getElementById("startPhrase");
var ambientMenu = new Audio('SOUND/ambientMenu.mp3');
ambientMenu.loop = true;

function startNewGame(){
	setTimeout(function(){startPhrase.style.opacity="0%"},500);
	setTimeout(function(){enot.style.opacity="0%"},2000);
	setTimeout(function(){flatBlackPlane.style.display="none"},5000);
	ambientMenu.play();
}
