//main variables
var botLeftXDistance=-10;
var botRightXDistance=10;
var botUpYDistance=10;
var botDownYDistance=-10;
var temp;
var vertical;
var rand;
var botLife=50;
var monsterDied = new Audio('SOUND/monsterDied.mp3');
var monsterPortalSound = new Audio('SOUND/monsterPortal.mp3');
var monsterInAttack = new Audio('SOUND/monsterInAttack.mp3');
var monsterInAttack2 = new Audio('SOUND/monsterInAttack2.mp3');
var m;
enemy=document.getElementById('monster');




function bot_get_coordinates(unit){
  // определение имени класса элемента "слева" от юнита
left_empty = document.elementFromPoint((unit.right-55),(unit.bottom-5)).className;
objLeft = document.elementFromPoint((unit.right-55),(unit.bottom-5));
if ( left_empty!="world" && left_empty!="we" && left_empty!="person" && left_empty!="w" && left_empty!="wc"&& left_empty!="ws" && left_empty!="wp" &&left_empty!="locked_door_white"&&left_empty!="locked_door_black" ) {
leftTemp=1;
if(left_empty=="irSensor"){
  objLeft.className = "deadMonster";
  unit.style.filter = "url(#yellow-outline)";
  setTimeout(function(){unit.style.filter = "none"},200);
  botLife-=1;
  plasmaGunShoot.play();
}
}
else{
  leftTemp=0;  
}
// определение имени класса элемента "справа" от юнита
right_empty  = document.elementFromPoint((unit.right+5),(unit.bottom-5)).className;
objRight = document.elementFromPoint((unit.right+5),(unit.bottom-5));
if ( right_empty!="world" && right_empty!="we" && right_empty!="person" && right_empty!="w" && right_empty!="wc"&& right_empty!="ws" && right_empty!="wp" &&right_empty!="locked_door_white"&&right_empty!="locked_door_black" ) {
 rightTemp=1;
 if(right_empty=="irSensor"){
  objRight.className = "deadMonster";
  unit.style.filter = "url(#yellow-outline)";
  setTimeout(function(){unit.style.filter = "none"},200);
  botLife-=1;
  plasmaGunShoot.play();
}
}
else{
  rightTemp=0; 
}
// определение имени класса элемента "снизу" от юнита
down_empty = document.elementFromPoint((unit.right-25),(unit.bottom+5)).className;
objDown = document.elementFromPoint((unit.right-25),(unit.bottom+5));
if ( down_empty!="world" && down_empty!="we" && down_empty!="person" && down_empty!="w" && down_empty!="wc"&& down_empty!="ws" && down_empty!="wp" &&down_empty!="locked_door_white"&&down_empty!="locked_door_black" ) {
downTemp=1;
if(down_empty=="irSensor"){
  objDown.className = "deadMonster";
  unit.style.filter = "url(#yellow-outline)";
  setTimeout(function(){unit.style.filter = "none"},200);
  botLife-=1;
  plasmaGunShoot.play();
}
}
else{
  downTemp=0; 
}
// определение имени класса элемента "сверху" от юнита
up_empty = document.elementFromPoint((unit.right-25),(unit.bottom-55)).className;
objUp = document.elementFromPoint((unit.right-25),(unit.bottom-55));
if ( up_empty!="world" && up_empty!="we" && up_empty!="person" && up_empty!="w" && up_empty!="wc"&& up_empty!="ws" && up_empty!="wp" &&up_empty!="locked_door_white"&&up_empty!="locked_door_black" ) {
upTemp=1;
if(up_empty=="irSensor"){
  objUp.className = "deadMonster";
  unit.style.filter = "url(#yellow-outline)";
  setTimeout(function(){unit.style.filter = "none"},200);
  botLife-=1;
  plasmaGunShoot.play();
}
}
else{
  upTemp=0;
   }
}


setInterval(function(){rand=Math.floor(Math.random() * (6 - 0)) + 0},2000);




function Bot(name){
  this.name = name;
  this.className='enemy';
  this.Life = 50;
  this.botLeftXDistance=-10;
  this.botRightXDistance=10;
  this.botUpYDistance=10;
  this.botDownYDistance=-10;
  this.temp;
  this.vertical;
  this.rand;
  this.moveRight=function(distance) {
    bot_get_coordinates(this.name);
    this.style.backgroundImage='URL("IMG/monster_r.gif")';
    if (rightTemp==1) {
      temp=temp+distance;
      this.style.left = temp + 'px';
      this.innerHTML=botLife;
      console.log("unit move right");
    }
  }
  this.moveLeft=function(distance) {
    bot_get_coordinates(this.name);
    this.style.backgroundImage='URL("IMG/monster_l.gif")';
    if (leftTemp==1) {
      temp=temp+distance;
      this.style.left = temp + 'px';
      this.innerHTML=botLife;
      console.log("unit move left");
    }
  }
  this.moveUp=function(distance) {
    bot_get_coordinates(this.name);
    this.style.backgroundImage='URL("IMG/monster_r.gif")';
    if (upTemp==1) {
      vertical=vertical+distance;
      this.style.bottom = vertical + 'px';
      this.innerHTML=botLife;
        console.log("unit move up");
    }
  }
  this.moveDown=function(distance) {
    bot_get_coordinates(this.name);
    this.style.backgroundImage='URL("IMG/monster_l.gif")';
    if (downTemp==1) {
      vertical=vertical+distance;
      this.style.bottom = vertical + 'px';
      this.innerHTML=botLife;
      console.log("unit move down");
    }
  }
  this.showEnemy = function (){
    this.style.display="inline-block";
    monsterPortalSound.play();
  }
  this.insertDeadBotBody = function() {
    var deadMonster = document.createElement('div');
    deadMonster.className = "deadMonster";
    deadMonster.style.left=this.style.left;
    deadMonster.style.bottom=this.style.bottom;
    game.append(deadMonster);
  }
  this.botMove = function(){
    if(this.Life<=0){
      monsterDied.play();
      if(toggle==0){
        // вставка тела мертвого монстра
        this.insertDeadBotBody();
        clearInterval(timerId);
        this.style.display="none";
      }
      else{
        // вставка тела мертвого монстра и респавн
        this.insertDeadBotBody();
        this.style.display="none";
        setTimeout(this.showEnemy,100);
        this.Life=50;
        // monsterPortal.style.left=enemy.style.left;
        // monsterPortal.style.bottom=enemy.style.bottom;
        // portaltemp=+monsterPortal.style.left.toString().slice(0, -2);
        // portalvertical=+monsterPortal.style.bottom.toString().slice(0, -2);
        temp=portaltemp;
        vertical=portalvertical;
        this.style.left=temp+'px';
        this.style.bottom=vertical+'px';
      }
    }
    try{
      var p = figure.getBoundingClientRect();
      m = this.getBoundingClientRect();
      // отслеживание столкновений с ботом
      if(( (p.bottom-m.bottom)<=50 && (p.bottom-m.bottom)>=-50 ) && ( (p.right-m.right)<=50 && (p.right-m.right)>=-50 ) ) {
        if(life<0){
          panel.innerHTML="life: "+ life;;
          showMassege();
          setTimeout(exit, 5000);
        }
        else{
          life-=1;
          localStorage.setItem('life', life);
          panel.innerHTML="life: " + life;
          figure.innerHTML="<span>"+life+"</span>";
          figure.style.filter = "url(#yellow-outline)";
          setTimeout(function(){figure.style.filter = "none"},200);
          monsterAttack.play();
        }
      }

      if(p.right-m.right<200 && p.right-m.right>0){
        this.moveRight(this.botRightXDistance);
      }
      if(p.right-m.right>-200 && p.right-m.right<0){
        this.moveLeft(this.botLeftXDistance);
      }
      if(p.bottom-m.bottom<200 && p.bottom-m.bottom>0){
        this.moveDown(this.botDownYDistance);
      }
      if(p.bottom-m.bottom>-200 && p.bottom-m.bottom<0){
        this.moveUp(this.botUpYDistance);
      }
      else{
        if(rand==0){
          this.moveRight(this.botRightXDistance);
        }
        else
        if(rand==1){
          this.moveLeft(this.botLeftXDistance);
        }
        else
        if(rand==2){
          this.moveUp(this.botUpYDistance);
        }
        else
        if(rand==3){
          this.moveDown(this.botDownYDistance);
        }
        else
        if(rand==4){
          monsterInAttack.play();
        }
        else
        if(rand==5){
          monsterInAttack2.play();
        }
      }
    }
    catch(e){
      console.log(e);
    }
  }

}

let bot = new Bot("enemy");

setInterval(bot.botMove, 200);