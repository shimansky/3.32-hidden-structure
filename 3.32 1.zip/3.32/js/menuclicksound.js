var menuClickSound = new Audio('SOUND/irSensor.mp3');
    function timedClick(element) {
  this.event.preventDefault();
  menuClickSound.play();
  element.innerText = "loading...";
  element.fontSize = "50px";
  setTimeout(() => window.location = element.href, 500);
}